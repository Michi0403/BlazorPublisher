﻿using System.Globalization;
using System.IO.Compression;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Components.Web;
using DevExpress.Blazor;
using Microsoft.JSInterop;
using PublisherStudio.BusinessObjects;
using PublisherStudio.Services;
using PublisherStudio.Services.PictureStudio.Import;
using PublisherStudio.Services.OrganicPlugins;
using PublisherStudio.Services.UserExperience;
using PublisherStudio.Services.Configuration;

namespace PublisherStudio.Components.Editor;

/// <summary>
/// Represents a picture editor.
/// </summary>
public partial class PictureEditor
{
    private readonly string[] PictureColors =
    [
        "#000000", "#ffffff", "#ef4444", "#f97316", "#eab308", "#22c55e", "#06b6d4", "#3b82f6", "#8b5cf6", "#ec4899", "#64748b", "#92400e"
    ];

    [Inject] private IJSRuntime JS { get; set; } = default!;
    [Inject] private SystemFontCatalog SystemFonts { get; set; } = default!;
    /// <summary>
    /// Gets or sets state.
    /// </summary>
    [Inject] public PictureEditorStateService State { get; set; } = default!;
    [Inject] private OpenRasterImportService OpenRasterImporter { get; set; } = default!;
    [Inject] private ILocalGptConnectionService LocalGptConnection { get; set; } = default!;
    [Inject] private IUserNotificationService Notifications { get; set; } = default!;
    [Inject] private ILogger<PictureEditor> Logger { get; set; } = default!;
    [Inject] private IPublisherRuntimePolicyDataService RuntimePolicy { get; set; } = default!;
    [Inject] private PublicationFileService Files { get; set; } = default!;

    /// <summary>
    /// Gets or sets whether the item is visible.
    /// </summary>
    [Parameter] public bool Visible { get; set; }
    /// <summary>
    /// Gets or sets session identifier.
    /// </summary>
    [Parameter] public Guid SessionId { get; set; }
    /// <summary>
    /// Gets or sets initial document.
    /// </summary>
    [Parameter] public PictureDocument? InitialDocument { get; set; }
    /// <summary>
    /// Gets or sets initial raster data URL.
    /// </summary>
    [Parameter] public string? InitialRasterDataUrl { get; set; }
    /// <summary>
    /// Gets or sets initial name.
    /// </summary>
    [Parameter] public string InitialName { get; set; } = "Picture";
    /// <summary>
    /// Gets or sets editing existing.
    /// </summary>
    [Parameter] public bool EditingExisting { get; set; }
    /// <summary>
    /// Gets or sets saved.
    /// </summary>
    [Parameter] public EventCallback<PictureEditorResult> Saved { get; set; }
    /// <summary>
    /// Gets or sets cancelled.
    /// </summary>
    [Parameter] public EventCallback Cancelled { get; set; }

    private IReadOnlyList<string> PictureFonts => SystemFonts.FontFamilies;

    private IJSObjectReference? _module;
    private DxContextMenu _pictureContextMenu = default!;
    private DotNetObjectReference<PictureEditor>? _self;
    private Guid _loadedSession;
    private bool _renderRequested;
    private bool _initialized;
    private bool _pendingRasterInitialization;
    private string? _error;
    private string? _notice;
    private bool _renderErrorActive;
    private PictureDrawTool _drawTool = PictureDrawTool.Select;
    private string _drawColor = "#111827";
    private string _drawSecondaryColor = "#ffffff";
    private double _drawWidth = 12;
    private double _drawOpacity = 1;
    private double _drawHardness = .8;
    private StringBuilder? _pictureExportBuffer;
    private string? _pictureExportId;
    private PictureDocument? _pictureExportSourceDocument;
    private string? _pictureExportName;
    private string _pictureExportPurpose = "save";
    private string _ocrText = string.Empty;
    private string _ocrStatus = string.Empty;
    private bool _ocrBusy;
    private int _pictureExportExpectedChunks;
    private int _pictureExportNextChunk;
    private int _pictureExportExpectedLength;
    private Guid? _replaceRasterLayerId;
    private double? _pendingDropX;
    private double? _pendingDropY;

    private bool HasSelection => State.SelectedLayer is not null;
    private bool CanDelete => State.SelectedLayer is { Locked: false };
    private bool HasLayerClip => State.SelectedLayer is { ClipPolygon.Count: >= 3 };
    private bool IsRenderSelected => State.SelectedLayer is RenderPictureLayer;
    private bool IsRasterSelected => State.SelectedLayer is RasterPictureLayer;
    private bool IsPaintSelected => State.SelectedLayer is PaintPictureLayer;
    private bool CanDraw => _drawTool != PictureDrawTool.Select;
    private bool IsPictureExporting => _pictureExportId is not null;
    private bool CanUseLocalGptOcr => Visible && LocalGptConnection.State.IsLinked && LocalGptConnection.State.HasCapability("localgpt.vision.ocr");
    private bool HasOcrText => !string.IsNullOrWhiteSpace(_ocrText);
    private string SelectToolText => ToolText(PictureDrawTool.Select, "Select");
    private string BrushToolText => ToolText(PictureDrawTool.Brush, "Brush");
    private string PencilToolText => ToolText(PictureDrawTool.Pencil, "Pencil");
    private string SprayToolText => ToolText(PictureDrawTool.Spray, "Spray can");
    private string ToothbrushToolText => ToolText(PictureDrawTool.Toothbrush, "Toothbrush");
    private string SquareToolText => ToolText(PictureDrawTool.Square, "Square");
    private string RectangleToolText => ToolText(PictureDrawTool.Rectangle, "Rectangle");
    private string EllipseToolText => ToolText(PictureDrawTool.Ellipse, "Ellipse");
    private string ArrowToolText => ToolText(PictureDrawTool.Arrow, "Arrow");
    private string LineToolText => ToolText(PictureDrawTool.Line, "Line");
    private string PathToolText => ToolText(PictureDrawTool.Path, "Path");
    private string EraserToolText => ToolText(PictureDrawTool.Eraser, "Eraser");
    private string EyedropperToolText => ToolText(PictureDrawTool.Eyedropper, "Eyedropper");
    private string RectangleSelectToolText => ToolText(PictureDrawTool.RectangleSelect, "Rectangle select");
    private string EllipseSelectToolText => ToolText(PictureDrawTool.EllipseSelect, "Ellipse select");
    private string FreeSelectToolText => ToolText(PictureDrawTool.FreeSelect, "Freehand select");
    private string MagneticSelectToolText => ToolText(PictureDrawTool.MagneticSelect, "Magnetic select");
    private string PolygonSelectToolText => ToolText(PictureDrawTool.PolygonSelect, "Polygon select");
    private string FillSolidToolText => ToolText(PictureDrawTool.FillSolid, "Solid fill");
    private string FillGradientToolText => ToolText(PictureDrawTool.FillGradient, "Gradient fill");
    private double BrushWidthSliderValue => WidthToSlider(_drawWidth);
    private string BrushWidthSliderStyle => $"--picture-range-progress: {Inv(BrushWidthSliderValue)}%;";
    private string DrawWidthDisplay => $"{_drawWidth:0.##} px";
    private string CanvasHint => _drawTool switch
    {
        PictureDrawTool.Select => "Drag layers directly. Corner handles resize; the round handle rotates. Right-click for layer commands.",
        PictureDrawTool.Eyedropper => "Click the rendered canvas to pick a color, then the Brush tool becomes active.",
        PictureDrawTool.Line => "Drag from the line start to its end. Hold the pointer down for a live preview.",
        PictureDrawTool.Path => "Click to place straight vector nodes. Double-click or press Enter to finish; hold Shift while finishing to close the path. Nodes remain editable.",
        PictureDrawTool.Eraser => "Draw over strokes on a paint layer to erase them non-destructively.",
        PictureDrawTool.RectangleSelect => "Drag a rectangular area selection. Use a fill tool to turn it into an editable layer.",
        PictureDrawTool.EllipseSelect => "Drag an elliptical area selection. Use a fill tool to turn it into an editable layer.",
        PictureDrawTool.FreeSelect => "Draw a freehand lasso around the area you want to fill.",
        PictureDrawTool.MagneticSelect => "Draw a lasso that snaps to nearby layer edges and corners.",
        PictureDrawTool.PolygonSelect => "Click/tap vertices in any angle. Double-click or press Enter to close the polygon, then keep, cut, copy, or fill that region.",
        PictureDrawTool.FillSolid => "Click to fill the current area selection, or drag a new rectangular filled area.",
        PictureDrawTool.FillGradient => "Click to gradient-fill the current area selection, or drag a new rectangular gradient area.",
        PictureDrawTool.Spray => "Spray paint scatters soft droplets around the pointer path for airbrush-like shading.",
        PictureDrawTool.Toothbrush => "Toothbrush lays down rough bristle streaks and splatter for textured paint effects.",
        PictureDrawTool.Square => "Drag a square directly onto the canvas. The result remains an editable shape layer.",
        PictureDrawTool.Rectangle => "Drag a rectangle directly onto the canvas. The result remains an editable shape layer.",
        PictureDrawTool.Ellipse => "Drag an ellipse directly onto the canvas. The result remains an editable shape layer.",
        PictureDrawTool.Arrow => "Drag from the arrow tail to its point. The result remains an editable, rotatable shape layer.",
        _ => "Draw directly on the canvas. A paint layer is created automatically when necessary. Right-click does not draw."
    };
    private string CanvasColor => State.Document.Background.StartsWith('#') && State.Document.Background.Length is 4 or 7
        ? State.Document.Background
        : "#ffffff";
    private string StatusText => _error ?? _notice ?? (IsPictureExporting
        ? "Rendering PNG for the publication…"
        : _drawTool != PictureDrawTool.Select
            ? $"{_drawTool} tool · {_drawWidth:0.#} px · {_drawColor}"
            : State.SelectedLayer is null ? "No layer selected" : $"{State.SelectedLayer.Kind}: {State.SelectedLayer.Name}");

    /// <summary>
    /// Runs the on initialized operation.
    /// </summary>
    protected override void OnInitialized()
    {
        State.Changed += StateChanged;
        LocalGptConnection.Changed += LocalGptConnectionChanged;
    }

    private void LocalGptConnectionChanged() => _ = InvokeAsync(StateHasChanged);

    /// <summary>
    /// Runs the on parameters set operation.
    /// </summary>
    protected override void OnParametersSet()
    {
        if (!Visible)
        {
            // The conditional Razor block removes the canvas from the DOM. Rebind the new canvas on the next open.
            _initialized = false;
            return;
        }
        if (SessionId == Guid.Empty || SessionId == _loadedSession) return;
        _loadedSession = SessionId;
        _error = null;
        _notice = null;
        _renderErrorActive = false;
        _drawTool = PictureDrawTool.Select;
        ClearPendingDropPosition();
        if (InitialDocument is not null)
        {
            _pendingRasterInitialization = false;
            State.StartFromDocument(InitialDocument);
        }
        else if (!string.IsNullOrWhiteSpace(InitialRasterDataUrl))
        {
            // Natural pixel dimensions are resolved after the JS module is available.
            _pendingRasterInitialization = true;
            State.StartNew();
            State.SetDocumentName(InitialName);
        }
        else
        {
            _pendingRasterInitialization = false;
            State.StartNew();
        }
        _renderRequested = true;
    }

    /// <summary>
    /// Runs the on after render async operation.
    /// </summary>
    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (!Visible) return;
        _module ??= await JS.InvokeAsync<IJSObjectReference>("import", "./js/pictureStudioInterop.js");
        _self ??= DotNetObjectReference.Create(this);
        if (_pendingRasterInitialization && !string.IsNullOrWhiteSpace(InitialRasterDataUrl))
        {
            _pendingRasterInitialization = false;
            if (!IsSupportedImageDataUrl(InitialRasterDataUrl))
            {
                _error = "The selected picture does not contain a valid embedded image source.";
                State.StartNew();
                State.SetDocumentName(InitialName);
            }
            else
            {
                try
                {
                    var natural = await _module.InvokeAsync<PictureImageSize>("getPictureImageSize", InitialRasterDataUrl);
                    var fitted = FitRasterCanvasSize(natural.Width, natural.Height);
                    State.StartFromRaster(InitialRasterDataUrl, InitialName, fitted.Width, fitted.Height);
                }
                catch (Exception ex)
                {
                    _error = $"The source image could not be decoded: {ex.Message}";
                    State.StartNew();
                    State.SetDocumentName(InitialName);
                }
            }
        }
        if (!_initialized)
        {
            await _module.InvokeVoidAsync(
                "initializePictureStudio",
                RuntimePolicy.PictureStudio.CanvasId,
                _self,
                RuntimePolicy.PictureStudio.StudioRootId,
                RuntimePolicy.PictureStudio.ImageDropInputId,
                RuntimePolicy.PictureStudio.LayerDropInputId);
            _initialized = true;
            _renderRequested = true;
        }
        if (_renderRequested)
        {
            _renderRequested = false;
            await RenderCanvasAsync();
        }
    }

    private void StateChanged()
    {
        _renderRequested = true;
        _ = InvokeAsync(StateHasChanged);
    }

    private async Task RenderCanvasAsync()
    {
        if (_module is null || !Visible) return;
        try
        {
            await _module.InvokeVoidAsync("renderPictureStudio", RuntimePolicy.PictureStudio.CanvasId, State.Document, State.SelectedLayerId?.ToString(), State.Document.Zoom, new
            {
                Tool = _drawTool.ToString(),
                Color = _drawColor,
                SecondaryColor = _drawSecondaryColor,
                Width = _drawWidth,
                Opacity = _drawOpacity,
                Hardness = _drawHardness
            });
        }
        catch (JSDisconnectedException)
        {
            // The browser circuit is closing.
        }
        catch (Exception ex)
        {
            _error = ex.Message;
            await InvokeAsync(StateHasChanged);
        }
    }

    /// <summary>
    /// Runs the picture layer selected operation.
    /// </summary>
    [JSInvokable]
    public void PictureLayerSelected(string? id)
    {
        State.SelectLayer(Guid.TryParse(id, out var parsed) ? parsed : null);
    }

    /// <summary>
    /// Runs the picture transform committed operation.
    /// </summary>
    [JSInvokable]
    public void PictureTransformCommitted(string id, double x, double y, double width, double height, double rotation)
    {
        if (Guid.TryParse(id, out var parsed))
            State.CommitTransform(parsed, x, y, width, height, rotation);
    }

    /// <summary>
    /// Runs the picture stroke committed operation.
    /// </summary>
    [JSInvokable]
    public void PictureStrokeCommitted(string tool, double[] coordinates, string color, double width, double opacity, double hardness)
    {
        if (!Enum.TryParse<PictureStrokeKind>(tool, true, out var kind) || coordinates.Length < 4) return;
        var points = new List<PicturePoint>(coordinates.Length / 2);
        for (var index = 0; index + 1 < coordinates.Length; index += 2)
            points.Add(new PicturePoint { X = coordinates[index], Y = coordinates[index + 1] });
        State.AddStroke(kind, points, color, width, opacity, hardness);
    }

    /// <summary>
    /// Runs the picture shape committed operation.
    /// </summary>
    [JSInvokable]
    public void PictureShapeCommitted(string tool, double x, double y, double width, double height, double rotation)
    {
        var shape = tool?.Trim().ToLowerInvariant() switch
        {
            "ellipse" => PictureShapeKind.Ellipse,
            "arrow" => PictureShapeKind.Arrow,
            _ => PictureShapeKind.Rectangle
        };
        State.AddShapeAt(shape, x, y, width, height, rotation);
        SetDrawTool(PictureDrawTool.Select);
    }

    /// <summary>
    /// Runs the picture path committed operation.
    /// </summary>
    [JSInvokable]
    public void PicturePathCommitted(double[] coordinates, bool closed, bool smooth)
    {
        if (coordinates.Length < 4) return;
        var points = new List<PicturePoint>(coordinates.Length / 2);
        for (var index = 0; index + 1 < coordinates.Length; index += 2)
            points.Add(new PicturePoint { X = coordinates[index], Y = coordinates[index + 1] });
        State.AddPath(points, _drawColor, _drawWidth, closed, smooth);
        SetDrawTool(PictureDrawTool.Select);
    }

    /// <summary>
    /// Runs the picture area fill committed operation.
    /// </summary>
    [JSInvokable]
    public void PictureAreaFillCommitted(string selectionKind, double[] coordinates, string primaryColor, string secondaryColor, bool gradient)
    {
        if (coordinates.Length < 4) return;
        var points = new List<PicturePoint>(coordinates.Length / 2);
        for (var index = 0; index + 1 < coordinates.Length; index += 2)
            points.Add(new PicturePoint { X = coordinates[index], Y = coordinates[index + 1] });
        State.AddAreaFill(selectionKind, points, primaryColor, secondaryColor, gradient);
        SetDrawTool(PictureDrawTool.Select);
    }

    /// <summary>
    /// Runs the picture color picked operation.
    /// </summary>
    [JSInvokable]
    public void PictureColorPicked(string color)
    {
        if (!string.IsNullOrWhiteSpace(color)) _drawColor = color;
        _drawTool = PictureDrawTool.Brush;
        _renderRequested = true;
        _ = InvokeAsync(StateHasChanged);
    }

    /// <summary>
    /// Runs the picture shortcut requested operation.
    /// </summary>
    [JSInvokable]
    public async Task PictureShortcutRequested(string command)
    {
        switch (command?.Trim().ToLowerInvariant())
        {
            case "undo": State.Undo(); break;
            case "redo": State.Redo(); break;
            case "copy":
                if (!await CopyAreaSelectionToClipboardAsync()) State.CopySelected();
                break;
            case "paste": State.Paste(); break;
            case "duplicate": State.DuplicateSelected(); break;
            case "delete":
                if (!await ApplyAreaClipAsync(inverted: true, quietWhenMissing: true)) State.DeleteSelected();
                break;
            case "front": State.BringSelectedToFront(); break;
            case "back": State.SendSelectedToBack(); break;
            case "select": SetDrawTool(PictureDrawTool.Select); break;
        }
    }

    /// <summary>
    /// Runs the picture render failed operation.
    /// </summary>
    [JSInvokable]
    public void PictureRenderFailed(string message)
    {
        _renderErrorActive = true;
        _error = string.IsNullOrWhiteSpace(message) ? "A picture layer could not be rendered." : message;
        _ = InvokeAsync(StateHasChanged);
    }

    /// <summary>
    /// Runs the picture render recovered operation.
    /// </summary>
    [JSInvokable]
    public void PictureRenderRecovered()
    {
        if (!_renderErrorActive) return;
        _renderErrorActive = false;
        _error = null;
        _ = InvokeAsync(StateHasChanged);
    }

    private async Task ShowCanvasContextMenu(MouseEventArgs args)
    {
        if (_module is not null && args.Button == 2)
        {
            var id = await _module.InvokeAsync<string?>("hitTestPictureStudioLayer", RuntimePolicy.PictureStudio.CanvasId, args.ClientX, args.ClientY);
            State.SelectLayer(Guid.TryParse(id, out var parsed) ? parsed : null);
        }
        await InvokeAsync(StateHasChanged);
        await _pictureContextMenu.ShowAsync(args);
    }

    private async Task ShowLayerContextMenu(PictureLayer layer, MouseEventArgs args)
    {
        State.SelectLayer(layer.Id);
        await InvokeAsync(StateHasChanged);
        await _pictureContextMenu.ShowAsync(args);
    }

    private async Task ShowLayerListContextMenu(MouseEventArgs args)
    {
        State.SelectLayer(null);
        await InvokeAsync(StateHasChanged);
        await _pictureContextMenu.ShowAsync(args);
    }

    private async Task RequestImage()
    {
        _replaceRasterLayerId = null;
        await JS.InvokeVoidAsync("publisherStudio.clickElement", RuntimePolicy.PictureStudio.ImageInputId);
    }

    private async Task RequestLayeredImport()
    {
        _replaceRasterLayerId = null;
        await JS.InvokeVoidAsync("publisherStudio.clickElement", RuntimePolicy.PictureStudio.LayeredInputId);
    }

    private async Task RequestRasterReplacement()
    {
        if (State.SelectedLayer is not RasterPictureLayer { Locked: false } raster) return;
        _replaceRasterLayerId = raster.Id;
        await JS.InvokeVoidAsync("publisherStudio.clickElement", RuntimePolicy.PictureStudio.ImageInputId);
    }

    private Task ImportImage(InputFileChangeEventArgs args) => ImportImageCore(args, forceAdd: false);

    private Task ImportDroppedImage(InputFileChangeEventArgs args) => ImportImageCore(args, forceAdd: true);

    private async Task ImportImageCore(InputFileChangeEventArgs args, bool forceAdd)
    {
        try
        {
            var file = args.File;
            var allowed = new[] { "image/png", "image/jpeg", "image/gif", "image/webp", "image/svg+xml" };
            if (!allowed.Contains(file.ContentType, StringComparer.OrdinalIgnoreCase))
                throw new InvalidDataException("Unsupported picture format.");

            await using var stream = file.OpenReadStream(long.MaxValue);
            using var buffer = new MemoryStream();
            await stream.CopyToAsync(buffer);
            var dataUrl = $"data:{file.ContentType};base64,{Convert.ToBase64String(buffer.ToArray())}";
            var size = _module is null
                ? new PictureImageSize()
                : await _module.InvokeAsync<PictureImageSize>("getPictureImageSize", dataUrl);
            if (!forceAdd && _replaceRasterLayerId is Guid targetId && State.ReplaceRaster(targetId, dataUrl))
                State.SelectLayer(targetId);
            else
                State.AddRaster(dataUrl, file.Name, size.Width, size.Height,
                    forceAdd ? _pendingDropX : null, forceAdd ? _pendingDropY : null);
        }
        catch (Exception ex)
        {
            _error = ex.Message;
        }
        finally
        {
            _replaceRasterLayerId = null;
            if (forceAdd) ClearPendingDropPosition();
        }
    }

    private Task ImportLayeredDocument(InputFileChangeEventArgs args) => ImportLayeredDocumentCore(args, append: false);

    private Task ImportDroppedLayeredDocument(InputFileChangeEventArgs args) => ImportLayeredDocumentCore(args, append: true);

    private async Task ImportLayeredDocumentCore(InputFileChangeEventArgs args, bool append)
    {
        _error = null;
        _notice = null;
        try
        {
            var file = args.File;
            var extension = Path.GetExtension(file.Name).ToLowerInvariant();
            PictureImportResult result;
            await using var stream = file.OpenReadStream(long.MaxValue);
            if (extension == ".ora")
            {
                result = await OpenRasterImporter.ImportAsync(stream, file.Name);
            }
            else if (extension is ".svg" or ".svgz" || file.ContentType.Equals("image/svg+xml", StringComparison.OrdinalIgnoreCase))
            {
                if (_module is null) throw new InvalidOperationException("Picture Studio is not ready yet.");
                string svgText;
                if (extension == ".svgz" || file.ContentType.Contains("gzip", StringComparison.OrdinalIgnoreCase))
                {
                    using var gzip = new GZipStream(stream, CompressionMode.Decompress, leaveOpen: true);
                    svgText = await ReadSvgTextAsync(gzip);
                }
                else
                {
                    svgText = await ReadSvgTextAsync(stream);
                }
                var dataUrl = $"data:image/svg+xml;base64,{Convert.ToBase64String(Encoding.UTF8.GetBytes(svgText))}";
                result = await _module.InvokeAsync<PictureImportResult>("importPictureStudioSvg", dataUrl, file.Name);
            }
            else
            {
                throw new InvalidDataException("Use an SVG, compressed SVGZ, or OpenRaster ORA document.");
            }

            if (append)
            {
                var added = State.AddImportedLayers(result.Document, Path.GetFileNameWithoutExtension(file.Name),
                    _pendingDropX, _pendingDropY);
                if (added == 0) throw new InvalidDataException("The dropped picture document does not contain importable layers.");
            }
            else
            {
                State.StartFromDocument(result.Document);
                State.SetDocumentName(Path.GetFileNameWithoutExtension(file.Name));
            }
            var losses = result.Issues.Count(item => item.Severity == InterchangeIssueSeverity.Loss);
            var warnings = result.Issues.Count(item => item.Severity == InterchangeIssueSeverity.Warning);
            var importedCount = append ? result.Document.Layers.Count : State.Document.Layers.Count;
            _notice = $"{(append ? "Added" : "Imported")} {importedCount} editable layer{(importedCount == 1 ? string.Empty : "s")}." +
                (losses + warnings > 0 ? $" {warnings} warning(s), {losses} compatibility loss(es)." : string.Empty);
        }
        catch (Exception ex)
        {
            _error = ex.Message;
        }
        finally
        {
            if (append) ClearPendingDropPosition();
        }
    }

    /// <summary>
    /// Runs the picture studio file drop positioned operation.
    /// </summary>
    [JSInvokable]
    public void PictureStudioFileDropPositioned(double? x, double? y)
    {
        _pendingDropX = x is double px && double.IsFinite(px) ? Math.Clamp(px, 0, State.Document.WidthPx) : null;
        _pendingDropY = y is double py && double.IsFinite(py) ? Math.Clamp(py, 0, State.Document.HeightPx) : null;
    }

    private void ClearPendingDropPosition()
    {
        _pendingDropX = null;
        _pendingDropY = null;
    }

    /// <summary>
    /// Runs the picture studio file drop rejected operation.
    /// </summary>
    [JSInvokable]
    public void PictureStudioFileDropRejected(string? message)
    {
        ClearPendingDropPosition();
        _error = string.IsNullOrWhiteSpace(message)
            ? "Drop a PNG, JPEG, GIF, WebP, SVG, SVGZ, or OpenRaster picture into Picture Studio."
            : message;
        _ = InvokeAsync(StateHasChanged);
    }

    private void AddTextLayer() => State.AddText();
    private void AddRectangle() => State.AddShape(PictureShapeKind.Rectangle);
    private void AddEllipse() => State.AddShape(PictureShapeKind.Ellipse);
    private void AddArrowShape() => State.AddShape(PictureShapeKind.Arrow);
    private void AddLineShape() => State.AddShape(PictureShapeKind.Line);
    private void AddGradient() => State.AddFill(PictureFillKind.LinearGradient);
    private void AddSolidFill() => State.AddFill(PictureFillKind.Solid);
    private void AddClouds() => State.AddRender(PictureRenderKind.Clouds);
    private void AddNoise() => State.AddRender(PictureRenderKind.Noise);
    private void AddStripes() => State.AddRender(PictureRenderKind.Stripes);
    private void AddVignette() => State.AddRender(PictureRenderKind.Vignette);
    private void AddBloom() => State.AddRender(PictureRenderKind.Bloom);
    private void AddNeon() => State.AddRender(PictureRenderKind.Neon);
    private void AddLensFlare() => State.AddRender(PictureRenderKind.LensFlare);
    private void AddGrainNoise() => State.AddRender(PictureRenderKind.GrainNoise);
    private void AddMotionBlur() => State.AddRender(PictureRenderKind.MotionBlur);
    private void AddWind() => State.AddRender(PictureRenderKind.Wind);
    private void AddOceanWaves() => State.AddRender(PictureRenderKind.OceanWaves);
    private void AddPaintLayer() => State.AddPaint();
    private void MoveUp() => State.MoveSelectedLayer(1);
    private void MoveDown() => State.MoveSelectedLayer(-1);
    private void Zoom100() => State.SetZoom(1);

    private async Task FitCanvas()
    {
        if (_module is null) return;
        var zoom = await _module.InvokeAsync<double>("fitPictureStudio", RuntimePolicy.PictureStudio.CanvasHostId, State.Document.WidthPx, State.Document.HeightPx);
        State.SetZoom(zoom);
    }

    private async Task Apply()
    {
        if (_module is null || _self is null || _pictureExportId is not null) return;

        var exportId = Guid.NewGuid().ToString("N");
        var sourceDocument = State.CloneDocument();
        _pictureExportId = exportId;
        _pictureExportSourceDocument = sourceDocument;
        _pictureExportName = State.Document.Name;
        _pictureExportPurpose = "save";
        _pictureExportBuffer = null;
        _pictureExportExpectedChunks = 0;
        _pictureExportNextChunk = 0;
        _pictureExportExpectedLength = 0;
        _error = null;

        try
        {
            // Generate the same PNG that the Download button produces, but feed the
            // data URL back in small chunks. This avoids the failing Blob stream
            // reference and the 32 KB Interactive Server message-size ceiling.
            // The JavaScript function starts the export and returns immediately;
            // CompletePictureExport performs the actual insert after all chunks arrive.
            await _module.InvokeVoidAsync(
                "startPictureStudioDataUrlExport",
                sourceDocument,
                "image/png",
                1d,
                _self,
                exportId);
        }
        catch (Exception ex)
        {
            if (IsCurrentPictureExport(exportId))
            {
                ResetPictureExport();
                _error = ex.Message;
            }
        }
    }

    /// <summary>
    /// Runs the begin picture export operation.
    /// </summary>
    [JSInvokable]
    public bool BeginPictureExport(string exportId, int totalLength, int chunkCount)
    {
        if (!IsCurrentPictureExport(exportId)) return false;
        if (totalLength <= 0)
        {
            FailPictureExport(exportId, "The rendered picture export reported an invalid length.");
            return false;
        }
        if (chunkCount <= 0)
        {
            FailPictureExport(exportId, "The rendered picture export contains an invalid chunk count.");
            return false;
        }

        _pictureExportExpectedLength = totalLength;
        _pictureExportExpectedChunks = chunkCount;
        _pictureExportNextChunk = 0;
        _pictureExportBuffer = new StringBuilder(Math.Min(totalLength, 1024 * 1024));
        return true;
    }

    /// <summary>
    /// Runs the append picture export chunk operation.
    /// </summary>
    [JSInvokable]
    public bool AppendPictureExportChunk(string exportId, int chunkIndex, string chunk)
    {
        if (!IsCurrentPictureExport(exportId) || _pictureExportBuffer is null) return false;
        if (chunkIndex != _pictureExportNextChunk)
        {
            FailPictureExport(exportId, "The rendered picture chunks arrived out of order.");
            return false;
        }
        _pictureExportBuffer.Append(chunk);
        _pictureExportNextChunk++;
        return true;
    }

    /// <summary>
    /// Runs the complete picture export operation.
    /// </summary>
    [JSInvokable]
    public async Task CompletePictureExport(string exportId)
    {
        if (!IsCurrentPictureExport(exportId) || _pictureExportBuffer is null) return;
        if (_pictureExportNextChunk != _pictureExportExpectedChunks ||
            _pictureExportBuffer.Length != _pictureExportExpectedLength)
        {
            FailPictureExport(exportId, "The rendered picture export was incomplete.");
            return;
        }

        var dataUrl = _pictureExportBuffer.ToString();
        if (!dataUrl.StartsWith("data:image/", StringComparison.OrdinalIgnoreCase) ||
            !dataUrl.Contains(",", StringComparison.Ordinal))
        {
            FailPictureExport(exportId, "The browser returned an invalid rendered picture.");
            return;
        }

        var sourceDocument = _pictureExportSourceDocument ?? State.CloneDocument();
        var name = string.IsNullOrWhiteSpace(_pictureExportName) ? State.Document.Name : _pictureExportName!;
        var purpose = _pictureExportPurpose;
        ResetPictureExport();
        if (string.Equals(purpose, "ocr", StringComparison.Ordinal))
        {
            await RequestLocalGptOcrAsync(dataUrl);
            return;
        }
        await DisposePictureRuntimeAsync();
        await InvokeAsync(() => Saved.InvokeAsync(new PictureEditorResult(dataUrl, sourceDocument, name)));
    }

    /// <summary>
    /// Runs the fail picture export operation.
    /// </summary>
    [JSInvokable]
    public void FailPictureExport(string exportId, string? message)
    {
        if (!IsCurrentPictureExport(exportId)) return;
        ResetPictureExport();
        _error = string.IsNullOrWhiteSpace(message) ? "The browser could not render the picture." : message;
        _ = InvokeAsync(StateHasChanged);
    }

    private bool IsCurrentPictureExport(string exportId) =>
        _pictureExportId is not null &&
        string.Equals(_pictureExportId, exportId, StringComparison.Ordinal);

    private void ResetPictureExport()
    {
        _pictureExportBuffer = null;
        _pictureExportId = null;
        _pictureExportSourceDocument = null;
        _pictureExportName = null;
        _pictureExportPurpose = "save";
        _pictureExportExpectedChunks = 0;
        _pictureExportNextChunk = 0;
        _pictureExportExpectedLength = 0;
    }

    private async Task StartLocalGptOcrAsync()
    {
        if (!CanUseLocalGptOcr || _module is null || _self is null || _pictureExportId is not null || _ocrBusy) return;
        var exportId = Guid.NewGuid().ToString("N");
        _pictureExportId = exportId;
        _pictureExportSourceDocument = State.CloneDocument();
        _pictureExportName = State.Document.Name;
        _pictureExportPurpose = "ocr";
        _pictureExportBuffer = null;
        _pictureExportExpectedChunks = 0;
        _pictureExportNextChunk = 0;
        _pictureExportExpectedLength = 0;
        _ocrStatus = "Rendering the current picture for LocalGPT OCR…";
        _error = null;
        try
        {
            await _module.InvokeVoidAsync("startPictureStudioDataUrlExport", _pictureExportSourceDocument, "image/jpeg", .9d, _self, exportId);
        }
        catch (Exception ex)
        {
            if (IsCurrentPictureExport(exportId)) ResetPictureExport();
            Logger.LogError(ex, "Could not render the Picture Studio canvas for LocalGPT OCR.");
            _error = ex.Message;
        }
    }

    private async Task RequestLocalGptOcrAsync(string dataUrl)
    {
        _ocrBusy = true;
        try
        {
            _ocrStatus = "Waiting for LocalGPT approval and local OCR…";
            await InvokeAsync(StateHasChanged);
            var envelope = new OrganicWireEnvelope
            {
                MessageType = OrganicWireMessageType.Invoke,
                TargetPeerId = LocalGptConnection.State.PeerId,
                CapabilityKey = "localgpt.vision.ocr",
                Controller = "OneWire",
                Method = "POST",
                Route = "/api/onewire/capabilities/localgpt.vision.ocr",
                Organs = ["eyes"],
                Skills = ["ocr", "vision", "text-recognition"],
                UserConfirmed = true,
                RequiresHumanInteractionOnTargetSystem = true,
                Properties = new Dictionary<string, JsonElement>
                {
                    ["Parameters"] = JsonSerializer.SerializeToElement(new
                    {
                        imageDataUrl = dataUrl,
                        modelName = "deepseek-ocr",
                        prompt = "Recognize all visible text in this PublisherStudio picture. Preserve reading order and line breaks. Return only recognized text and mark uncertainty with [?].",
                        maximumOutputTokens = 1600
                    })
                }
            };
            envelope.NormalizeInteractionKind();
            var correlationId = await LocalGptConnection.SendEnvelopeAsync(envelope);
            var deadline = DateTimeOffset.UtcNow.AddMinutes(6);
            while (true)
            {
                var remaining = deadline - DateTimeOffset.UtcNow;
                if (remaining <= TimeSpan.Zero) throw new TimeoutException("LocalGPT OCR did not finish within six minutes.");
                var response = await LocalGptConnection.WaitForResultAsync(correlationId, remaining);
                if (response.MessageType == OrganicWireMessageType.ApprovalRequired)
                {
                    _ocrStatus = "Approve the OCR request in the LocalGPT frontend; PublisherStudio will keep waiting for the same request.";
                    await InvokeAsync(StateHasChanged);
                    continue;
                }
                if (response.MessageType == OrganicWireMessageType.Error)
                    throw new InvalidOperationException(string.IsNullOrWhiteSpace(response.Error) ? "LocalGPT rejected the OCR request." : response.Error);
                if (response.MessageType != OrganicWireMessageType.WorkResult) continue;
                var resultJson = ReadWireString(response, "ResultJson");
                var result = JsonSerializer.Deserialize<PictureOcrResult>(resultJson, new JsonSerializerOptions(JsonSerializerDefaults.Web))
                    ?? throw new JsonException("The LocalGPT OCR result was empty.");
                if (string.IsNullOrWhiteSpace(result.Text)) throw new InvalidOperationException("LocalGPT returned no recognized text.");
                _ocrText = result.Text.Trim();
                _ocrStatus = $"OCR completed with {result.ModelName}. Review the text before inserting it as a layer.";
                Notifications.Success(_ocrStatus, "Picture Studio OCR", nameof(PictureEditor));
                break;
            }
        }
        catch (OperationCanceledException)
        {
            _ocrStatus = "LocalGPT OCR was cancelled.";
            Logger.LogInformation("Picture Studio LocalGPT OCR was cancelled.");
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Picture Studio LocalGPT OCR failed.");
            _ocrStatus = string.Empty;
            _error = ex.Message;
            Notifications.Error(ex.Message, "Picture Studio OCR failed", nameof(PictureEditor));
        }
        finally
        {
            _ocrBusy = false;
            await InvokeAsync(StateHasChanged);
        }
    }

    private void InsertOcrTextLayer()
    {
        if (string.IsNullOrWhiteSpace(_ocrText)) return;
        var layer = State.AddText();
        layer.Name = "OCR text";
        layer.Text = _ocrText;
        _notice = "Recognized text was inserted as an editable Picture Studio text layer.";
        Notifications.Success(_notice, "Picture Studio OCR", nameof(PictureEditor));
    }

    private void ClearOcrText()
    {
        _ocrText = string.Empty;
        _ocrStatus = string.Empty;
    }

    private string ReadWireString(OrganicWireEnvelope envelope, string key)
    {
        if (envelope.Properties is null || !envelope.Properties.TryGetValue(key, out var value)) return string.Empty;
        return value.ValueKind == JsonValueKind.String ? value.GetString() ?? string.Empty : value.GetRawText();
    }

    private async Task DownloadPng() => await Download("image/png", "png", 1d);
    private async Task DownloadJpeg() => await Download("image/jpeg", "jpg", .92d);
    private async Task DownloadSvg()
    {
        if (_module is null) return;
        var fileName = $"{Files.SafeFileName(State.Document.Name)}.svg";
        await _module.InvokeVoidAsync("downloadPictureStudioSvg", State.Document, fileName);
    }

    private async Task Download(string mimeType, string extension, double quality)
    {
        if (_module is null) return;
        try
        {
            var name = Files.SafeFileName(State.Document.Name) + "." + extension;
            await _module.InvokeVoidAsync("downloadPictureStudio", State.Document, name, mimeType, quality);
        }
        catch (Exception ex)
        {
            _error = ex.Message;
        }
    }

    private async Task Cancel()
    {
        await CancelPictureInteractionAsync();
        await DisposePictureRuntimeAsync();
        await Cancelled.InvokeAsync();
    }

    private void SelectTool() => SetDrawTool(PictureDrawTool.Select);
    private void BrushTool() => SetDrawTool(PictureDrawTool.Brush);
    private void PencilTool() => SetDrawTool(PictureDrawTool.Pencil);
    private void SprayTool() => SetDrawTool(PictureDrawTool.Spray);
    private void ToothbrushTool() => SetDrawTool(PictureDrawTool.Toothbrush);
    private void SquareTool() => SetDrawTool(PictureDrawTool.Square);
    private void RectangleTool() => SetDrawTool(PictureDrawTool.Rectangle);
    private void EllipseTool() => SetDrawTool(PictureDrawTool.Ellipse);
    private void ArrowTool() => SetDrawTool(PictureDrawTool.Arrow);
    private void LineTool() => SetDrawTool(PictureDrawTool.Line);
    private void PathTool() => SetDrawTool(PictureDrawTool.Path);
    private void EraserTool() => SetDrawTool(PictureDrawTool.Eraser);
    private void EyedropperTool() => SetDrawTool(PictureDrawTool.Eyedropper);
    private void RectangleSelectTool() => SetDrawTool(PictureDrawTool.RectangleSelect);
    private void EllipseSelectTool() => SetDrawTool(PictureDrawTool.EllipseSelect);
    private void FreeSelectTool() => SetDrawTool(PictureDrawTool.FreeSelect);
    private void MagneticSelectTool() => SetDrawTool(PictureDrawTool.MagneticSelect);
    private void PolygonSelectTool() => SetDrawTool(PictureDrawTool.PolygonSelect);
    private void FillSolidTool() => SetDrawTool(PictureDrawTool.FillSolid);
    private void FillGradientTool() => SetDrawTool(PictureDrawTool.FillGradient);
    private async Task ClearAreaSelection()
    {
        if (_module is not null) await _module.InvokeVoidAsync("clearPictureStudioAreaSelection", RuntimePolicy.PictureStudio.CanvasId);
        _renderRequested = true;
    }

    private async Task<PictureAreaSelection?> ReadAreaSelectionAsync()
    {
        if (_module is null || State.SelectedLayer is null) return null;
        try
        {
            return await _module.InvokeAsync<PictureAreaSelection?>("getPictureStudioAreaSelection", RuntimePolicy.PictureStudio.CanvasId);
        }
        catch (JSDisconnectedException) { return null; }
        catch (TaskCanceledException) { return null; }
        catch (JSException) { return null; }
    }

    private List<PicturePoint> SelectionPolygon(PictureAreaSelection selection)
    {
        var points = selection.Points
            .Where(point => double.IsFinite(point.X) && double.IsFinite(point.Y))
            .Take(2048)
            .Select(point => new PicturePoint { X = point.X, Y = point.Y })
            .ToList();
        if (points.Count < 2) return [];

        var kind = selection.Kind?.Trim().ToLowerInvariant();
        if (kind == "rectangle")
        {
            var first = points[0];
            var last = points[^1];
            var left = Math.Min(first.X, last.X);
            var top = Math.Min(first.Y, last.Y);
            var right = Math.Max(first.X, last.X);
            var bottom = Math.Max(first.Y, last.Y);
            return
            [
                new PicturePoint { X = left, Y = top },
                new PicturePoint { X = right, Y = top },
                new PicturePoint { X = right, Y = bottom },
                new PicturePoint { X = left, Y = bottom }
            ];
        }

        if (kind == "ellipse")
        {
            var first = points[0];
            var last = points[^1];
            var centerX = (first.X + last.X) / 2;
            var centerY = (first.Y + last.Y) / 2;
            var radiusX = Math.Abs(last.X - first.X) / 2;
            var radiusY = Math.Abs(last.Y - first.Y) / 2;
            if (radiusX < .5 || radiusY < .5) return [];
            return Enumerable.Range(0, 48)
                .Select(index => index * Math.PI * 2 / 48)
                .Select(angle => new PicturePoint
                {
                    X = centerX + Math.Cos(angle) * radiusX,
                    Y = centerY + Math.Sin(angle) * radiusY
                })
                .ToList();
        }

        while (points.Count > 1 && Distance(points[0], points[^1]) < .25) points.RemoveAt(points.Count - 1);
        return points.Count >= 3 ? points : [];
    }

    private async Task<bool> ApplyAreaClipAsync(bool inverted, bool quietWhenMissing = false)
    {
        var selection = await ReadAreaSelectionAsync();
        var polygon = selection is null ? [] : SelectionPolygon(selection);
        if (polygon.Count < 3)
        {
            if (!quietWhenMissing) _notice = "Create an area selection first. Polygon select accepts any number of angled lines.";
            return false;
        }
        if (!State.ApplySelectedClip(polygon, inverted))
        {
            if (!quietWhenMissing) _notice = "Select an unlocked layer before applying the area cut.";
            return false;
        }
        _notice = inverted ? "The selected area was cut from the layer non-destructively." : "The layer now keeps only the selected area.";
        await ClearAreaSelection();
        SetDrawTool(PictureDrawTool.Select);
        return true;
    }

    private Task KeepSelectedArea() => ApplyAreaClipAsync(inverted: false);
    private Task CutSelectedArea() => ApplyAreaClipAsync(inverted: true);

    private async Task<bool> CopyAreaSelectionToClipboardAsync()
    {
        var selection = await ReadAreaSelectionAsync();
        var polygon = selection is null ? [] : SelectionPolygon(selection);
        if (polygon.Count < 3 || !State.CopySelectedRegion(polygon)) return false;
        _notice = "Selected picture region copied. Paste inserts it as an independently editable clipped layer.";
        return true;
    }

    private async Task CopySelectedArea()
    {
        if (!await CopyAreaSelectionToClipboardAsync())
            _notice = "Create an area selection on a layer before copying a region.";
    }

    private async Task CopySelectedAreaAsLayer()
    {
        if (!await CopyAreaSelectionToClipboardAsync())
        {
            _notice = "Create an area selection on a layer before copying a region.";
            return;
        }
        State.Paste();
        await ClearAreaSelection();
        SetDrawTool(PictureDrawTool.Select);
        _notice = "The selected region was inserted as a new clipped layer.";
    }

    private void ClearLayerCut()
    {
        if (State.ClearSelectedClip()) _notice = "The layer cut was cleared.";
    }

    private double Distance(PicturePoint first, PicturePoint second)
    {
        var x = first.X - second.X;
        var y = first.Y - second.Y;
        return Math.Sqrt(x * x + y * y);
    }
    private void SetDrawTool(PictureDrawTool tool)
    {
        _ = CancelPictureInteractionAsync();
        _drawTool = tool;
        _renderRequested = true;
        StateHasChanged();
    }

    private async Task CancelPictureInteractionAsync()
    {
        if (_module is null) return;
        try
        {
            await _module.InvokeVoidAsync("cancelPictureStudioInteraction", RuntimePolicy.PictureStudio.CanvasId);
        }
        catch (JSDisconnectedException) { }
        catch (TaskCanceledException) { }
        catch (JSException) { }
    }

    private async Task DisposePictureRuntimeAsync()
    {
        if (_module is null || !_initialized) return;
        try
        {
            await _module.InvokeVoidAsync("disposePictureStudio", RuntimePolicy.PictureStudio.CanvasId);
        }
        catch (JSDisconnectedException) { }
        catch (TaskCanceledException) { }
        catch (JSException) { }
        finally
        {
            _initialized = false;
        }
    }
    private string ToolText(PictureDrawTool tool, string text) => _drawTool == tool ? $"✓ {text}" : text;
    private bool IsDrawWidth(double value) => Math.Abs(_drawWidth - value) < .001;
    private string DrawWidthText(double value) => IsDrawWidth(value) ? $"✓ {value:0.##} px" : $"{value:0.##} px";
    private string DrawWidthButtonClass(double value) => IsDrawWidth(value) ? "selected" : string.Empty;
    private void ChangeDrawColor(string value) { if (!string.IsNullOrWhiteSpace(value)) _drawColor = value; _renderRequested = true; }
    private void ChangeDrawSecondaryColor(string value) { if (!string.IsNullOrWhiteSpace(value)) _drawSecondaryColor = value; _renderRequested = true; }
    private void SetDrawWidth(double value)
    {
        _drawWidth = Math.Clamp(value, RuntimePolicy.PictureStudio.MinimumDrawWidth, RuntimePolicy.PictureStudio.MaximumDrawWidth);
        _renderRequested = true;
    }
    private double WidthToSlider(double width)
    {
        var clamped = Math.Clamp(width, RuntimePolicy.PictureStudio.MinimumDrawWidth, RuntimePolicy.PictureStudio.MaximumDrawWidth);
        return Math.Log(clamped / RuntimePolicy.PictureStudio.MinimumDrawWidth) / Math.Log(RuntimePolicy.PictureStudio.MaximumDrawWidth / RuntimePolicy.PictureStudio.MinimumDrawWidth) * 100;
    }
    private double SliderToWidth(double slider)
    {
        var normalized = Math.Clamp(slider, 0, 100) / 100;
        var width = RuntimePolicy.PictureStudio.MinimumDrawWidth * Math.Pow(RuntimePolicy.PictureStudio.MaximumDrawWidth / RuntimePolicy.PictureStudio.MinimumDrawWidth, normalized);
        var step = width switch
        {
            < 4 => .25,
            < 16 => .5,
            < 64 => 1,
            < 128 => 2,
            _ => 4
        };
        return Math.Round(width / step) * step;
    }
    private void DrawWidth1() => SetDrawWidth(1);
    private void DrawWidth3() => SetDrawWidth(3);
    private void DrawWidth8() => SetDrawWidth(8);
    private void DrawWidth16() => SetDrawWidth(16);
    private void DrawWidth32() => SetDrawWidth(32);
    private void ToggleGridRibbon() => State.SetGrid(!State.Document.GridVisible);
    private void ToggleSnapRibbon() => State.SetSnap(!State.Document.SnapToGrid);
    private string GridText => State.Document.GridVisible ? "✓ Grid" : "Grid";
    private string SnapText => State.Document.SnapToGrid ? "✓ Snap" : "Snap";
    private void MakeRenderClouds() => WithRender(layer => layer.RenderKind = PictureRenderKind.Clouds);
    private void MakeRenderNoise() => WithRender(layer => layer.RenderKind = PictureRenderKind.Noise);
    private void MakeRenderStripes() => WithRender(layer => layer.RenderKind = PictureRenderKind.Stripes);
    private void MakeRenderVignette() => WithRender(layer => layer.RenderKind = PictureRenderKind.Vignette);
    private void MakeRenderBloom() => WithRender(layer => layer.RenderKind = PictureRenderKind.Bloom);
    private void MakeRenderNeon() => WithRender(layer => layer.RenderKind = PictureRenderKind.Neon);
    private void MakeRenderLensFlare() => WithRender(layer => layer.RenderKind = PictureRenderKind.LensFlare);
    private void MakeRenderGrainNoise() => WithRender(layer => layer.RenderKind = PictureRenderKind.GrainNoise);
    private void MakeRenderMotionBlur() => WithRender(layer => layer.RenderKind = PictureRenderKind.MotionBlur);
    private void MakeRenderWind() => WithRender(layer => layer.RenderKind = PictureRenderKind.Wind);
    private void MakeRenderOceanWaves() => WithRender(layer => layer.RenderKind = PictureRenderKind.OceanWaves);
    private void RasterContain() => WithRaster(layer => layer.FitMode = PictureRasterFitMode.Contain);
    private void RasterCover() => WithRaster(layer => layer.FitMode = PictureRasterFitMode.Cover);
    private void RasterStretch() => WithRaster(layer => layer.FitMode = PictureRasterFitMode.Stretch);
    private void RasterFlipHorizontal() => WithRaster(layer => layer.FlipHorizontal = !layer.FlipHorizontal);
    private void RasterFlipVertical() => WithRaster(layer => layer.FlipVertical = !layer.FlipVertical);
    private void RasterRotateLeft() => WithRaster(layer => layer.Rotation = (layer.Rotation - 90 + 360) % 360);
    private void RasterRotateRight() => WithRaster(layer => layer.Rotation = (layer.Rotation + 90) % 360);
    private void RasterResetRotation() => WithRaster(layer => layer.Rotation = 0);
    private void RasterNoTint() => WithRaster(layer => layer.TintOpacity = 0);
    private void RasterBlueTint() => WithRaster(layer => { layer.TintColor = "#2563eb"; layer.TintOpacity = .28; });
    private void RasterWarmTint() => WithRaster(layer => { layer.TintColor = "#f97316"; layer.TintOpacity = .24; });
    private void SoftenLight() => State.UpdateSelected(layer => layer.Blur = 2);
    private void SoftenMedium() => State.UpdateSelected(layer => layer.Blur = 6);
    private void RemoveSoftening() => State.UpdateSelected(layer => layer.Blur = 0);
    private void Brighten() => State.UpdateSelected(layer => layer.Brightness = Math.Clamp(layer.Brightness + .1, 0, 3));
    private void Darken() => State.UpdateSelected(layer => layer.Brightness = Math.Clamp(layer.Brightness - .1, 0, 3));
    private void MoreContrast() => State.UpdateSelected(layer => layer.Contrast = Math.Clamp(layer.Contrast + .1, 0, 3));
    private void MoreSaturation() => State.UpdateSelected(layer => layer.Saturation = Math.Clamp(layer.Saturation + .1, 0, 3));
    private void ToggleGrayscalePreset() => State.UpdateSelected(layer => layer.Grayscale = layer.Grayscale > .5 ? 0 : 1);
    private void ToggleSepiaPreset() => State.UpdateSelected(layer => layer.Sepia = layer.Sepia > .5 ? 0 : 1);
    private void ToggleInvertPreset() => State.UpdateSelected(layer => layer.Invert = layer.Invert > .5 ? 0 : 1);
    private void ApplyBloomEffect() => State.UpdateSelected(layer =>
    {
        layer.Brightness = Math.Clamp(layer.Brightness + .18, 0, 3);
        layer.Contrast = Math.Clamp(layer.Contrast + .06, 0, 3);
        layer.Saturation = Math.Clamp(layer.Saturation + .12, 0, 3);
        layer.Blur = Math.Clamp(Math.Max(layer.Blur, 4), 0, 50);
        layer.Opacity = Math.Clamp(layer.Opacity, .82, 1);
        layer.BlendMode = PictureBlendMode.Screen;
    });
    private void ApplyNeonEffect() => State.UpdateSelected(layer =>
    {
        layer.Brightness = Math.Clamp(layer.Brightness + .22, 0, 3);
        layer.Contrast = Math.Clamp(layer.Contrast + .25, 0, 3);
        layer.Saturation = Math.Clamp(layer.Saturation + .6, 0, 3);
        layer.Blur = Math.Clamp(Math.Max(layer.Blur, 1.5), 0, 50);
        layer.BlendMode = PictureBlendMode.Screen;
    });
    private void ApplyLensFlareEffect() => State.UpdateSelected(layer =>
    {
        layer.Brightness = Math.Clamp(layer.Brightness + .28, 0, 3);
        layer.Contrast = Math.Clamp(layer.Contrast + .12, 0, 3);
        layer.Saturation = Math.Clamp(layer.Saturation + .18, 0, 3);
        layer.Blur = Math.Clamp(Math.Max(layer.Blur, .75), 0, 50);
        layer.Opacity = Math.Clamp(layer.Opacity, .9, 1);
        layer.BlendMode = PictureBlendMode.Screen;
    });

    private void ShapeRectangle() => WithShape(layer => layer.Shape = PictureShapeKind.Rectangle);
    private void ShapeRoundedRectangle() => WithShape(layer => layer.Shape = PictureShapeKind.RoundedRectangle);
    private void ShapeEllipse() => WithShape(layer => layer.Shape = PictureShapeKind.Ellipse);
    private void ShapeArrow() => WithShape(layer => layer.Shape = PictureShapeKind.Arrow);
    private void ShapeLine() => WithShape(layer => layer.Shape = PictureShapeKind.Line);
    private void ShapePath() => WithShape(layer => layer.Shape = PictureShapeKind.Path);
    private void FillSolid() => WithFill(layer => layer.FillKind = PictureFillKind.Solid);
    private void FillLinearGradient() => WithFill(layer => layer.FillKind = PictureFillKind.LinearGradient);
    private void FillRadialGradient() => WithFill(layer => layer.FillKind = PictureFillKind.RadialGradient);
    private void SetPictureTextFont(string font) => WithText(layer => layer.FontFamily = font);
    private void SetPictureTextSize(double value) => WithText(layer => layer.FontSizePx = value);
    private void TextSize24() => SetPictureTextSize(24);
    private void TextSize48() => SetPictureTextSize(48);
    private void TextSize72() => SetPictureTextSize(72);
    private void TextSize120() => SetPictureTextSize(120);
    private void TextSize180() => SetPictureTextSize(180);
    private void TogglePictureTextBold() => WithText(layer => layer.Bold = !layer.Bold);
    private void TogglePictureTextItalic() => WithText(layer => layer.Italic = !layer.Italic);
    private void TogglePictureTextShadow() => WithText(layer => layer.ShadowEnabled = !layer.ShadowEnabled);
    private void TextAlignLeft() => WithText(layer => layer.Alignment = PictureTextAlignment.Left);
    private void TextAlignCenter() => WithText(layer => layer.Alignment = PictureTextAlignment.Center);
    private void TextAlignRight() => WithText(layer => layer.Alignment = PictureTextAlignment.Right);
    private void TextColorBlue() => WithText(layer => layer.FillColor = "#17365d");
    private void TextColorBlack() => WithText(layer => layer.FillColor = "#000000");
    private void TextColorWhite() => WithText(layer => layer.FillColor = "#ffffff");
    private void TextColorRed() => WithText(layer => layer.FillColor = "#dc2626");
    private void TextOutlineNone() => WithText(layer => { layer.OutlineColor = "transparent"; layer.OutlineWidthPx = 0; });
    private void TextOutlineThin() => WithText(layer => { layer.OutlineColor = "#111827"; layer.OutlineWidthPx = 1; });
    private void TextOutlineThick() => WithText(layer => { layer.OutlineColor = "#ffffff"; layer.OutlineWidthPx = 4; });
    private void ShapeFillSolid() => WithShape(layer => layer.FillKind = PictureFillKind.Solid);
    private void ShapeFillLinear() => WithShape(layer => layer.FillKind = PictureFillKind.LinearGradient);
    private void ShapeFillRadial() => WithShape(layer => layer.FillKind = PictureFillKind.RadialGradient);
    private void SetShapeColors(string first, string second, string stroke) => WithShape(layer => { layer.FillColor = first; layer.SecondaryFillColor = second; layer.StrokeColor = stroke; });
    private void ShapeColorsBlue() => SetShapeColors("#60a5fa", "#dbeafe", "#1d4ed8");
    private void ShapeColorsGreen() => SetShapeColors("#4ade80", "#dcfce7", "#15803d");
    private void ShapeColorsOrange() => SetShapeColors("#fb923c", "#ffedd5", "#c2410c");
    private void ShapeColorsMono() => SetShapeColors("#111827", "#ffffff", "#000000");
    private void SetShapeStroke(double width) => WithShape(layer => layer.StrokeWidthPx = width);
    private void ShapeStroke0() => SetShapeStroke(0);
    private void ShapeStroke1() => SetShapeStroke(1);
    private void ShapeStroke3() => SetShapeStroke(3);
    private void ShapeStroke8() => SetShapeStroke(8);
    private void SetFillColors(string first, string second) => WithFill(layer => { layer.PrimaryColor = first; layer.SecondaryColor = second; });
    private void FillColorsBlue() => SetFillColors("#dbeafe", "#6366f1");
    private void FillColorsGreen() => SetFillColors("#dcfce7", "#16a34a");
    private void FillColorsSunset() => SetFillColors("#fde68a", "#f97316");
    private void FillColorsMono() => SetFillColors("#ffffff", "#111827");
    private void SetFillAngle(double value) => WithFill(layer => layer.AngleDegrees = value);
    private void FillAngle0() => SetFillAngle(0);
    private void FillAngle45() => SetFillAngle(45);
    private void FillAngle90() => SetFillAngle(90);
    private void FillAngle180() => SetFillAngle(180);
    private void FillAngle270() => SetFillAngle(270);
    private void SetLayerOpacity(double value) => State.UpdateSelected(layer => layer.Opacity = value);
    private void LayerOpacity100() => SetLayerOpacity(1);
    private void LayerOpacity75() => SetLayerOpacity(.75);
    private void LayerOpacity50() => SetLayerOpacity(.5);
    private void LayerOpacity25() => SetLayerOpacity(.25);
    private void ToggleSelectedLockMenu()
    {
        if (State.SelectedLayer is PictureLayer layer) State.ToggleLock(layer.Id);
    }
    private void ToggleSelectedVisibilityMenu()
    {
        if (State.SelectedLayer is PictureLayer layer) State.ToggleVisibility(layer.Id);
    }
    private string CheckedText(bool selected, string text) => selected ? $"✓ {text}" : text;

    private void ChangeDocumentName(ChangeEventArgs args) => State.SetDocumentName(Text(args));
    private void ChangeCanvasWidth(ChangeEventArgs args) => State.SetDocumentSize(Int(args, State.Document.WidthPx), State.Document.HeightPx);
    private void ChangeCanvasHeight(ChangeEventArgs args) => State.SetDocumentSize(State.Document.WidthPx, Int(args, State.Document.HeightPx));
    private void ChangeBackgroundPreset(ChangeEventArgs args) => State.SetBackground(Text(args));
    private void ChangeCanvasColor(ChangeEventArgs args) => State.SetBackground(Text(args));
    private void ChangeGridSpacing(ChangeEventArgs args) => State.SetGridSpacing(Int(args, State.Document.GridSpacingPx));
    private void ToggleGrid(ChangeEventArgs args) => State.SetGrid(Bool(args));
    private void ToggleSnap(ChangeEventArgs args) => State.SetSnap(Bool(args));
    private void ChangeZoom(ChangeEventArgs args) => State.SetZoom(Number(args, State.Document.Zoom));
    private void ChangeDrawTool(ChangeEventArgs args)
    {
        if (Enum.TryParse<PictureDrawTool>(Text(args), true, out var tool)) SetDrawTool(tool);
    }
    private void ChangeDrawColorInput(ChangeEventArgs args) => ChangeDrawColor(Text(args));
    private void ChangeDrawSecondaryColorInput(ChangeEventArgs args) => ChangeDrawSecondaryColor(Text(args));
    private void ChangeDrawWidth(ChangeEventArgs args) => SetDrawWidth(Number(args, _drawWidth));
    private void ChangeDrawWidthSlider(ChangeEventArgs args) => SetDrawWidth(SliderToWidth(Number(args, BrushWidthSliderValue)));
    private void ChangeDrawOpacity(ChangeEventArgs args) { _drawOpacity = Math.Clamp(Number(args, _drawOpacity), 0, 1); _renderRequested = true; }
    private void ChangeDrawHardness(ChangeEventArgs args) { _drawHardness = Math.Clamp(Number(args, _drawHardness), 0, 1); _renderRequested = true; }

    private void PresetSquare() => State.SetDocumentSize(1200, 1200);
    private void PresetLandscape() => State.SetDocumentSize(1600, 1000);
    private void PresetFullHd() => State.SetDocumentSize(1920, 1080);
    private void PresetA4() => State.SetDocumentSize(2480, 3508);

    private void ChangeLayerName(ChangeEventArgs args) => State.UpdateSelected(layer => layer.Name = Text(args));
    private void ChangeLayerX(ChangeEventArgs args) => State.UpdateSelected(layer => layer.X = Number(args, layer.X));
    private void ChangeLayerY(ChangeEventArgs args) => State.UpdateSelected(layer => layer.Y = Number(args, layer.Y));
    private void ChangeLayerWidth(ChangeEventArgs args) => State.UpdateSelected(layer => layer.Width = Number(args, layer.Width));
    private void ChangeLayerHeight(ChangeEventArgs args) => State.UpdateSelected(layer => layer.Height = Number(args, layer.Height));
    private void ChangeLayerRotation(ChangeEventArgs args) => State.UpdateSelectedLive("layer-rotation", layer => layer.Rotation = Number(args, layer.Rotation));
    private void ChangeLayerOpacity(ChangeEventArgs args) => State.UpdateSelectedLive("layer-opacity", layer => layer.Opacity = Number(args, layer.Opacity));
    private void ChangeBlendMode(ChangeEventArgs args)
    {
        if (Enum.TryParse<PictureBlendMode>(Text(args), true, out var value))
            State.UpdateSelected(layer => layer.BlendMode = value);
    }
    private void ToggleSelectedVisibility(ChangeEventArgs args) => State.UpdateSelected(layer => layer.Visible = Bool(args), allowLocked: true);
    private void ToggleSelectedLock(ChangeEventArgs args) => State.UpdateSelected(layer => layer.Locked = Bool(args), allowLocked: true);
    private void EndLiveEdit(ChangeEventArgs _) => State.EndLiveEdit();

    private void ChangeRasterFit(ChangeEventArgs args)
    {
        if (Enum.TryParse<PictureRasterFitMode>(Text(args), true, out var value))
            WithRaster(layer => layer.FitMode = value);
    }
    private void ToggleRasterFlipHorizontal(ChangeEventArgs args) => WithRaster(layer => layer.FlipHorizontal = Bool(args));
    private void ToggleRasterFlipVertical(ChangeEventArgs args) => WithRaster(layer => layer.FlipVertical = Bool(args));
    private void ChangeRasterTintColor(ChangeEventArgs args) => WithRaster(layer => layer.TintColor = Text(args));
    private void ChangeRasterTintOpacity(ChangeEventArgs args) => WithRasterLive("raster-tint", layer => layer.TintOpacity = Number(args, layer.TintOpacity));

    private void ChangeTextContent(ChangeEventArgs args) => WithText(layer => layer.Text = Text(args));
    private void ChangeTextFont(ChangeEventArgs args) => WithText(layer => layer.FontFamily = Text(args));
    private void ChangeTextSize(ChangeEventArgs args) => WithText(layer => layer.FontSizePx = Number(args, layer.FontSizePx));
    private void ChangeTextAlignment(ChangeEventArgs args)
    {
        if (Enum.TryParse<PictureTextAlignment>(Text(args), true, out var value))
            WithText(layer => layer.Alignment = value);
    }
    private void ToggleTextBold(ChangeEventArgs args) => WithText(layer => layer.Bold = Bool(args));
    private void ToggleTextItalic(ChangeEventArgs args) => WithText(layer => layer.Italic = Bool(args));
    private void ToggleTextShadow(ChangeEventArgs args) => WithText(layer => layer.ShadowEnabled = Bool(args));
    private void ChangeTextFill(ChangeEventArgs args) => WithText(layer => layer.FillColor = Text(args));
    private void ChangeTextOutline(ChangeEventArgs args) => WithText(layer => layer.OutlineColor = Text(args));
    private void ChangeTextOutlineWidth(ChangeEventArgs args) => WithText(layer => layer.OutlineWidthPx = Number(args, layer.OutlineWidthPx));
    private void ChangeTextShadowBlur(ChangeEventArgs args) => WithText(layer => layer.ShadowBlurPx = Number(args, layer.ShadowBlurPx));

    private void ChangeShapeKind(ChangeEventArgs args)
    {
        if (Enum.TryParse<PictureShapeKind>(Text(args), true, out var value))
            WithShape(layer => layer.Shape = value);
    }
    private void ChangeShapeFillKind(ChangeEventArgs args)
    {
        if (Enum.TryParse<PictureFillKind>(Text(args), true, out var value)) WithShape(layer => layer.FillKind = value);
    }
    private void ChangeShapeFill(ChangeEventArgs args) => WithShape(layer => layer.FillColor = Text(args));
    private void ChangeShapeSecondaryFill(ChangeEventArgs args) => WithShape(layer => layer.SecondaryFillColor = Text(args));
    private void ChangeShapeFillAngle(ChangeEventArgs args) => State.UpdateSelectedLive("shape-fill-angle", layer => { if (layer is ShapePictureLayer shape) shape.FillAngleDegrees = Number(args, shape.FillAngleDegrees); });
    private void ChangeShapeStroke(ChangeEventArgs args) => WithShape(layer => layer.StrokeColor = Text(args));
    private void ChangeShapeStrokeWidth(ChangeEventArgs args) => WithShape(layer => layer.StrokeWidthPx = Number(args, layer.StrokeWidthPx));
    private void ChangeShapeRadius(ChangeEventArgs args) => WithShape(layer => layer.CornerRadiusPx = Number(args, layer.CornerRadiusPx));
    private void ToggleShapePathClosed(ChangeEventArgs args) => WithShape(layer => layer.PathClosed = Bool(args));
    private void ToggleShapePathSmooth(ChangeEventArgs args) => WithShape(layer => layer.PathSmooth = Bool(args));
    private void AddShapePathPoint() => WithShape(layer =>
    {
        layer.PathPoints ??= [];
        var previous = layer.PathPoints.LastOrDefault();
        layer.PathPoints.Add(new PicturePoint
        {
            X = Math.Clamp((previous?.X ?? layer.Width / 2) + 20, 0, Math.Max(1, layer.Width)),
            Y = Math.Clamp(previous?.Y ?? layer.Height / 2, 0, Math.Max(1, layer.Height))
        });
    });
    private void RemoveShapePathPoint(int index) => WithShape(layer =>
    {
        if (layer.PathPoints is { Count: > 2 } && index >= 0 && index < layer.PathPoints.Count)
            layer.PathPoints.RemoveAt(index);
    });
    private void ReverseShapePath() => WithShape(layer => { layer.PathPoints?.Reverse(); });
    private void ChangeShapePathPointX(int index, ChangeEventArgs args) => ChangeShapePathPoint(index, args, true);
    private void ChangeShapePathPointY(int index, ChangeEventArgs args) => ChangeShapePathPoint(index, args, false);
    private void ChangeShapePathPoint(int index, ChangeEventArgs args, bool horizontal) => WithShape(layer =>
    {
        if (layer.PathPoints is null || index < 0 || index >= layer.PathPoints.Count) return;
        var point = layer.PathPoints[index];
        if (horizontal) point.X = Math.Clamp(Number(args, point.X), -16384, 32768);
        else point.Y = Math.Clamp(Number(args, point.Y), -16384, 32768);
    });

    private void ChangeFillKind(ChangeEventArgs args)
    {
        if (Enum.TryParse<PictureFillKind>(Text(args), true, out var value))
            WithFill(layer => layer.FillKind = value);
    }
    private void ChangeFillPrimary(ChangeEventArgs args) => WithFill(layer => layer.PrimaryColor = Text(args));
    private void ChangeFillSecondary(ChangeEventArgs args) => WithFill(layer => layer.SecondaryColor = Text(args));
    private void ChangeFillAngle(ChangeEventArgs args) => WithFillLive("fill-angle", layer => layer.AngleDegrees = Number(args, layer.AngleDegrees));

    private void ChangeRenderKind(ChangeEventArgs args)
    {
        if (Enum.TryParse<PictureRenderKind>(Text(args), true, out var value))
            WithRender(layer => layer.RenderKind = value);
    }
    private void ChangeRenderPrimary(ChangeEventArgs args) => WithRender(layer => layer.PrimaryColor = Text(args));
    private void ChangeRenderSecondary(ChangeEventArgs args) => WithRender(layer => layer.SecondaryColor = Text(args));
    private void ChangeRenderSeed(ChangeEventArgs args) => WithRender(layer => layer.Seed = Int(args, layer.Seed));
    private void ChangeRenderScale(ChangeEventArgs args) => WithRender(layer => layer.Scale = Number(args, layer.Scale));
    private void ChangeRenderDetail(ChangeEventArgs args) => WithRender(layer => layer.Detail = Int(args, layer.Detail));
    private void ChangeRenderSoftness(ChangeEventArgs args) => WithRender(layer => layer.Softness = Number(args, layer.Softness));
    private void ChangeRenderContrast(ChangeEventArgs args) => WithRender(layer => layer.RenderContrast = Number(args, layer.RenderContrast));
    private void ChangeRenderStripeWidth(ChangeEventArgs args) => WithRender(layer => layer.StripeWidthPx = Number(args, layer.StripeWidthPx));
    private void ChangeRenderAngle(ChangeEventArgs args) => WithRenderLive("render-angle", layer => layer.AngleDegrees = Number(args, layer.AngleDegrees));
    private void RandomizeRender() => WithRender(layer => layer.Seed = Random.Shared.Next(1, int.MaxValue));
    private Task FocusRenderProperties() => JS.InvokeVoidAsync("publisherStudio.focusElement", "picture-render-properties").AsTask();
    private void RenderPrimaryWhite() => WithRender(layer => layer.PrimaryColor = "#ffffff");
    private void RenderPrimaryBlack() => WithRender(layer => layer.PrimaryColor = "#000000");
    private void RenderPrimaryBlue() => WithRender(layer => layer.PrimaryColor = "#2563eb");
    private void RenderSecondaryWhite() => WithRender(layer => layer.SecondaryColor = "#ffffff");
    private void RenderSecondaryBlack() => WithRender(layer => layer.SecondaryColor = "#000000");
    private void RenderSecondaryBlue() => WithRender(layer => layer.SecondaryColor = "#60a5fa");
    private void SetRenderScale(double value) => WithRender(layer => layer.Scale = value);
    private void RenderScale24() => SetRenderScale(24);
    private void RenderScale64() => SetRenderScale(64);
    private void RenderScale128() => SetRenderScale(128);
    private void RenderScale256() => SetRenderScale(256);
    private void SetRenderDetail(int value) => WithRender(layer => layer.Detail = value);
    private void RenderDetail1() => SetRenderDetail(1);
    private void RenderDetail2() => SetRenderDetail(2);
    private void RenderDetail4() => SetRenderDetail(4);
    private void RenderDetail6() => SetRenderDetail(6);
    private void RenderDetail8() => SetRenderDetail(8);
    private void SetRenderSoftness(double value) => WithRender(layer => layer.Softness = value);
    private void RenderSoftness0() => SetRenderSoftness(0);
    private void RenderSoftness25() => SetRenderSoftness(.25);
    private void RenderSoftness50() => SetRenderSoftness(.5);
    private void RenderSoftness75() => SetRenderSoftness(.75);
    private void RenderSoftness100() => SetRenderSoftness(1);
    private void SetRenderContrast(double value) => WithRender(layer => layer.RenderContrast = value);
    private void RenderContrast05() => SetRenderContrast(.5);
    private void RenderContrast10() => SetRenderContrast(1);
    private void RenderContrast15() => SetRenderContrast(1.5);
    private void RenderContrast20() => SetRenderContrast(2);
    private void RenderContrast30() => SetRenderContrast(3);
    private void SetRenderAngle(double value) => WithRender(layer => layer.AngleDegrees = value);
    private void RenderAngle0() => SetRenderAngle(0);
    private void RenderAngle45() => SetRenderAngle(45);
    private void RenderAngle90() => SetRenderAngle(90);
    private void RenderAngle180() => SetRenderAngle(180);
    private void RenderAngle270() => SetRenderAngle(270);
    private void SetRenderStripeWidth(double value) => WithRender(layer => layer.StripeWidthPx = value);
    private void RenderStripe8() => SetRenderStripeWidth(8);
    private void RenderStripe16() => SetRenderStripeWidth(16);
    private void RenderStripe32() => SetRenderStripeWidth(32);
    private void RenderStripe64() => SetRenderStripeWidth(64);
    private void RenderStripe128() => SetRenderStripeWidth(128);
    private void ResetRenderSettings() => WithRender(layer =>
    {
        layer.Scale = 90;
        layer.Detail = 4;
        layer.Softness = .6;
        layer.RenderContrast = 1;
        layer.AngleDegrees = 45;
        layer.StripeWidthPx = 32;
    });

    private void ChangeBrightness(ChangeEventArgs args) => State.UpdateSelectedLive("adjust-brightness", layer => layer.Brightness = Number(args, layer.Brightness));
    private void ChangeContrast(ChangeEventArgs args) => State.UpdateSelectedLive("adjust-contrast", layer => layer.Contrast = Number(args, layer.Contrast));
    private void ChangeSaturation(ChangeEventArgs args) => State.UpdateSelectedLive("adjust-saturation", layer => layer.Saturation = Number(args, layer.Saturation));
    private void ChangeHue(ChangeEventArgs args) => State.UpdateSelectedLive("adjust-hue", layer => layer.HueRotation = Number(args, layer.HueRotation));
    private void ChangeBlur(ChangeEventArgs args) => State.UpdateSelectedLive("adjust-blur", layer => layer.Blur = Number(args, layer.Blur));
    private void ChangeGrayscale(ChangeEventArgs args) => State.UpdateSelectedLive("adjust-grayscale", layer => layer.Grayscale = Number(args, layer.Grayscale));
    private void ChangeSepia(ChangeEventArgs args) => State.UpdateSelectedLive("adjust-sepia", layer => layer.Sepia = Number(args, layer.Sepia));
    private void ChangeInvert(ChangeEventArgs args) => State.UpdateSelectedLive("adjust-invert", layer => layer.Invert = Number(args, layer.Invert));

    private void ResetAdjustments()
    {
        State.UpdateSelected(layer =>
        {
            layer.Brightness = 1;
            layer.Contrast = 1;
            layer.Saturation = 1;
            layer.HueRotation = 0;
            layer.Blur = 0;
            layer.Grayscale = 0;
            layer.Sepia = 0;
            layer.Invert = 0;
        });
    }

    private void WithRaster(Action<RasterPictureLayer> update)
    {
        if (State.SelectedLayer is RasterPictureLayer layer) State.UpdateSelected(_ => update(layer));
    }
    private void WithRasterLive(string key, Action<RasterPictureLayer> update)
    {
        if (State.SelectedLayer is RasterPictureLayer layer) State.UpdateSelectedLive(key, _ => update(layer));
    }
    private void ToggleSvgPreserveAspectRatio(ChangeEventArgs args)
    {
        if (State.SelectedLayer is SvgPictureLayer svg)
            State.UpdateSelected(_ => svg.PreserveAspectRatio = Bool(args));
    }

    private void WithText(Action<TextPictureLayer> update)
    {
        if (State.SelectedLayer is TextPictureLayer layer) State.UpdateSelected(_ => update(layer));
    }
    private void WithShape(Action<ShapePictureLayer> update)
    {
        if (State.SelectedLayer is ShapePictureLayer layer) State.UpdateSelected(_ => update(layer));
    }
    private void WithFill(Action<FillPictureLayer> update)
    {
        if (State.SelectedLayer is FillPictureLayer layer) State.UpdateSelected(_ => update(layer));
    }
    private void WithFillLive(string key, Action<FillPictureLayer> update)
    {
        if (State.SelectedLayer is FillPictureLayer layer) State.UpdateSelectedLive(key, _ => update(layer));
    }
    private void WithRender(Action<RenderPictureLayer> update)
    {
        if (State.SelectedLayer is RenderPictureLayer layer) State.UpdateSelected(_ => update(layer));
    }
    private void WithRenderLive(string key, Action<RenderPictureLayer> update)
    {
        if (State.SelectedLayer is RenderPictureLayer layer) State.UpdateSelectedLive(key, _ => update(layer));
    }


    private async Task<string> ReadSvgTextAsync(Stream input)
    {
        using var buffer = new MemoryStream();
        await input.CopyToAsync(buffer);
        return new UTF8Encoding(false, true).GetString(buffer.ToArray());
    }

    private bool IsSupportedImageDataUrl(string value) =>
        value.StartsWith("data:image/", StringComparison.OrdinalIgnoreCase) && value.Contains(",", StringComparison.Ordinal);

    private PictureImageSize FitRasterCanvasSize(int width, int height)
    {
        if (width <= 0 || height <= 0) return new PictureImageSize { Width = 1200, Height = 800 };
        var scale = Math.Min(1d, 8192d / Math.Max(width, height));
        return new PictureImageSize
        {
            Width = Math.Clamp((int)Math.Round(width * scale), 16, 8192),
            Height = Math.Clamp((int)Math.Round(height * scale), 16, 8192)
        };
    }

    private string LayerIcon(PictureLayer layer) => layer.Kind switch
    {
        PictureLayerKind.Raster => "▧",
        PictureLayerKind.Text => "T",
        PictureLayerKind.Shape => "◇",
        PictureLayerKind.Fill => "◩",
        PictureLayerKind.Render => "☁",
        PictureLayerKind.Paint => "✎",
        PictureLayerKind.Vector => "⌘",
        _ => "•"
    };

    private string PictureTextFontSizeMenuText(TextPictureLayer text) =>
        $"Font size · {Math.Round(text.FontSizePx).ToString(CultureInfo.InvariantCulture)} px";

    private string RenderScaleMenuText(RenderPictureLayer render) =>
        $"Scale · {Math.Round(render.Scale).ToString(CultureInfo.InvariantCulture)} px";

    private string RenderDetailMenuText(RenderPictureLayer render) =>
        $"Detail · {render.Detail.ToString(CultureInfo.InvariantCulture)}";

    private string RenderSoftnessMenuText(RenderPictureLayer render) =>
        $"Softness · {Math.Round(render.Softness * 100).ToString(CultureInfo.InvariantCulture)}%";

    private string RenderContrastMenuText(RenderPictureLayer render) =>
        $"Contrast · {render.RenderContrast.ToString("0.0", CultureInfo.InvariantCulture)}×";

    private string RenderAngleMenuText(RenderPictureLayer render) =>
        $"Angle · {Math.Round(render.AngleDegrees).ToString(CultureInfo.InvariantCulture)}°";

    private string RenderStripeWidthMenuText(RenderPictureLayer render) =>
        $"Stripe width · {Math.Round(render.StripeWidthPx).ToString(CultureInfo.InvariantCulture)} px";

    private string LayerDescription(PictureLayer layer) => layer switch
    {
        RasterPictureLayer raster => raster.FitMode.ToString(),
        SvgPictureLayer svg => string.IsNullOrWhiteSpace(svg.GroupPath) ? svg.SourceFormat : $"{svg.SourceFormat} · {svg.GroupPath}",
        TextPictureLayer text => Truncate(text.Text, 28),
        ShapePictureLayer shape => shape.Shape.ToString(),
        FillPictureLayer fill => fill.FillKind.ToString(),
        RenderPictureLayer render => render.RenderKind.ToString(),
        PaintPictureLayer paint => $"{paint.Strokes.Count} stroke{(paint.Strokes.Count == 1 ? string.Empty : "s")}",
        _ => layer.Kind.ToString()
    };

    private string Truncate(string value, int length) => string.IsNullOrWhiteSpace(value)
        ? "Empty"
        : value.Length <= length ? value : value[..length] + "…";

    private string Text(ChangeEventArgs args) => Convert.ToString(args.Value, CultureInfo.InvariantCulture)?.Trim() ?? string.Empty;
    private bool Bool(ChangeEventArgs args) => args.Value is bool value && value;
    private double Number(ChangeEventArgs args, double fallback) => double.TryParse(Text(args), NumberStyles.Float, CultureInfo.InvariantCulture, out var value) ? value : fallback;
    private int Int(ChangeEventArgs args, int fallback) => int.TryParse(Text(args), NumberStyles.Integer, CultureInfo.InvariantCulture, out var value) ? value : fallback;
    private string Inv(double value) => value.ToString("0.###", CultureInfo.InvariantCulture);
    private string SafeColor(string value) => value.StartsWith('#') && value.Length is 4 or 7 ? value : "#000000";

    /// <summary>
    /// Runs the dispose operation.
    /// </summary>
    public void Dispose()
    {
        State.Changed -= StateChanged;
        LocalGptConnection.Changed -= LocalGptConnectionChanged;
    }

    /// <summary>
    /// Runs the dispose async operation.
    /// </summary>
    public async ValueTask DisposeAsync()
    {
        State.Changed -= StateChanged;
        LocalGptConnection.Changed -= LocalGptConnectionChanged;
        _self?.Dispose();
        try
        {
            await DisposePictureRuntimeAsync();
            if (_module is not null) await _module.DisposeAsync();
        }
        catch (JSDisconnectedException) { }
        catch (TaskCanceledException) { }
    }

    private sealed class PictureAreaSelection
    {
        /// <summary>
        /// Gets or sets kind.
        /// </summary>
        public string Kind { get; set; } = "polygon";
        /// <summary>
        /// Gets or sets points.
        /// </summary>
        public List<PicturePoint> Points { get; set; } = [];
    }

    private sealed class PictureOcrResult
    {
        /// <summary>
        /// Gets or sets text.
        /// </summary>
        public string Text { get; set; } = string.Empty;
        /// <summary>
        /// Gets or sets model name.
        /// </summary>
        public string ModelName { get; set; } = string.Empty;
        /// <summary>
        /// Gets or sets provider URI.
        /// </summary>
        public string ProviderUri { get; set; } = string.Empty;
        /// <summary>
        /// Gets or sets media type.
        /// </summary>
        public string MediaType { get; set; } = string.Empty;
        /// <summary>
        /// Gets or sets needs human review.
        /// </summary>
        public bool NeedsHumanReview { get; set; } = true;
    }

    private sealed class PictureImageSize
    {
        /// <summary>
        /// Runs the picture image size operation.
        /// </summary>
        public PictureImageSize() { }
        /// <summary>
        /// Gets or sets width.
        /// </summary>
        public int Width { get; set; }
        /// <summary>
        /// Gets or sets height.
        /// </summary>
        public int Height { get; set; }
    }
}
