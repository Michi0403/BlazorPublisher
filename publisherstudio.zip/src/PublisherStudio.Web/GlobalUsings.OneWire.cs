global using LocalGPT.WireProtocol;
