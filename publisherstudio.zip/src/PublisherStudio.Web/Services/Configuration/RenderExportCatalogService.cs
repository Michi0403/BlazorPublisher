﻿using PublisherStudio.BusinessObjects;

namespace PublisherStudio.Services.Configuration;

/// <summary>
/// Provides render export catalog service operations.
/// </summary>
public sealed class RenderExportCatalogService(ILogger<RenderExportCatalogService> logger) : IRenderExportCatalogService
{
    private readonly IReadOnlyList<RenderExportCapability> _capabilities = new List<RenderExportCapability>
    {
        new() { Format = "png", MimeType = "image/png", CapturesVideoFrames = true, CapturesCanvasEffects = true, PreservesVectorContent = false, HtmlSupport = PublicationHtmlExportSupport.CanvasRuntime, Note = "Rendered still frame with live video/effect canvases frozen at export time." },
        new() { Format = "jpg", MimeType = "image/jpeg", CapturesVideoFrames = true, CapturesCanvasEffects = true, PreservesVectorContent = false, HtmlSupport = PublicationHtmlExportSupport.CanvasRuntime, Note = "Rendered opaque still frame; transparency is flattened." },
        new() { Format = "svg", MimeType = "image/svg+xml", CapturesVideoFrames = true, CapturesCanvasEffects = true, PreservesVectorContent = true, HtmlSupport = PublicationHtmlExportSupport.CanvasRuntime, Note = "SVG foreignObject export; live media and effect canvases are embedded as frozen images." },
        new() { Format = "html", MimeType = "text/html", CapturesVideoFrames = false, CapturesCanvasEffects = true, PreservesVectorContent = true, HtmlSupport = PublicationHtmlExportSupport.Native, Note = "Interactive export. Effects marked RenderBeforeExport require baking first." },
        new() { Format = "pdf", MimeType = "application/pdf", CapturesVideoFrames = true, CapturesCanvasEffects = true, PreservesVectorContent = false, HtmlSupport = PublicationHtmlExportSupport.RenderBeforeExport, Note = "Browser print path; dynamic media is represented by its current rendered frame." }
    }.AsReadOnly();

    /// <summary>
    /// Gets capabilities.
    /// </summary>
    public IReadOnlyList<RenderExportCapability> GetCapabilities() {
        try
        {
            logger.LogTrace($"Entering RenderExportCatalogService.GetCapabilities.");
            return _capabilities;
        }
        catch (Exception exception)
        {
            logger.LogError(exception, $"RenderExportCatalogService.GetCapabilities failed: {exception.Message}");
            throw;
        }
    }
    /// <summary>
    /// Runs the find operation.
    /// </summary>
    public RenderExportCapability? Find(string format) {
        try
        {
            logger.LogTrace($"Entering RenderExportCatalogService.Find.");
            return _capabilities.FirstOrDefault(item => string.Equals(item.Format, format?.TrimStart('.'), StringComparison.OrdinalIgnoreCase));
        }
        catch (Exception exception)
        {
            logger.LogError(exception, $"RenderExportCatalogService.Find failed: {exception.Message}");
            throw;
        }
    }
}
