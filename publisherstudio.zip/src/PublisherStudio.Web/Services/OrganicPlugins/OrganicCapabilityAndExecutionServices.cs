﻿using PublisherStudio.BusinessObjects;
using PublisherStudio.Services;
using PublisherStudio.Services.Automation;
using PublisherStudio.Services.MediaConversion;
using PublisherStudio.Services.OpenScad;
using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text.Json;

namespace PublisherStudio.Services.OrganicPlugins;

/// <summary>
/// Provides organic capability catalog operations.
/// </summary>
public sealed class OrganicCapabilityCatalog(
    IMediaConversionService mediaConversion,
    ILogger<OrganicCapabilityCatalog> logger) : IOrganicCapabilityCatalog
{
    /// <summary>
    /// Gets capabilities async.
    /// </summary>
    public async Task<IReadOnlyList<OrganicCapabilityDescriptor>> GetCapabilitiesAsync(CancellationToken cancellationToken = default)
    {
        var media = await mediaConversion.GetCapabilitiesAsync(cancellationToken).ConfigureAwait(false);
        var capabilities = new List<OrganicCapabilityDescriptor>
        {
            Capability("publisher.screen.capture", "Eyes: screen capture", "Captures one user-selected screen or window only after PublisherStudio confirmation and the browser's current getDisplayMedia prompt.", "eyes", false, true, false),
            Capability("publisher.screen.record", "Eyes: screen recording", "Records a user-selected screen or window for up to 15 seconds after PublisherStudio confirmation and a fresh browser prompt.", "eyes", false, true, false),
            Capability("publisher.screen.capture.result", "Eyes: screen capture result", "Reads the bounded status and result of a previously queued browser screenshot for the next council heartbeat.", "eyes", true, false, true),
            Capability("publisher.screenreader.start", "Start recurring screen-reader help", "Starts one debounced single-flight screen-reader session. The interval is clamped to at least 15 seconds.", "eyes", false, true, true),
            Capability("publisher.screenreader.stop", "Stop recurring screen-reader help", "Stops a recurring screen-reader session by id.", "eyes", false, true, true),
            Capability("publisher.input.execute", "Hands: browser input", "Queues one bounded mouse, keyboard, hover, focus or gesture command through the existing automation service.", "hands", false, true, true),
            Capability("publisher.input.result", "Hands: browser input result", "Reads the status and bounded result of a previously queued browser input command.", "eyes", true, false, true),
            Capability("publisher.openscad.generate", "OpenSCAD canonical project generation", "Validates and renders a canonical OpenScadDocument/OpenScadNode graph through the existing registered renderer path.", "hands", false, true, false),
            Capability("publisher.spreadsheet.inspect", "Spreadsheet session inspection", "Returns bounded metadata and preview evidence for an existing workbook session without mutation.", "eyes", true, true, true),
            Capability("publisher.text.insert.propose", "Propose text insertion", "Creates a reviewable text insertion proposal. It never mutates a publication automatically.", "hands", false, true, true),
            Capability("publisher.text.edit.request", "Request reviewed text", "Opens a bounded PublisherStudio text editor after approval, returns the user's saved text through the same CorrelationId, then closes the editor automatically.", "hands", false, true, false),
            Capability("publisher.website.content.request", "Request approved web/document content", "Returns user-approved bounded HTML, DIV or document content plus an optional source URL for LocalGPT chat and other organic clients.", "eyes", true, true, false),
            Capability("publisher.business-context", "PublisherStudio project/API context", "Returns the current domain, service and controller context for grounded council planning.", "eyes", true, false, false),
            Capability("publisher.media.capabilities", "FFmpeg/media capabilities", $"Returns the installed PublisherStudio media conversion capability map. FFmpeg available: {media.Available}.", "eyes", true, false, false)
        };
        logger.LogDebug("Published {CapabilityCount} PublisherStudio organic capabilities.", capabilities.Count);
        return capabilities;
    }

    /// <summary>
    /// Gets skills async.
    /// </summary>
    public async Task<IReadOnlyList<OrganicSkillDescriptor>> GetSkillsAsync(CancellationToken cancellationToken = default)
    {
        var capabilities = await GetCapabilitiesAsync(cancellationToken).ConfigureAwait(false);
        return capabilities
            .SelectMany(capability => capability.Skills.Select(skill => new { skill, capability }))
            .GroupBy(item => item.skill, StringComparer.OrdinalIgnoreCase)
            .Select(group => new OrganicSkillDescriptor
            {
                Key = group.Key,
                DisplayName = group.Key,
                Description = $"PublisherStudio organic skill backed by {group.Select(item => item.capability.Key).Distinct().Count()} capability route(s).",
                SourcePeerId = "publisherstudio",
                Organs = group.SelectMany(item => item.capability.Organs).Distinct(StringComparer.OrdinalIgnoreCase).ToList(),
                CapabilityKeys = group.Select(item => item.capability.Key).Distinct(StringComparer.OrdinalIgnoreCase).ToList(),
                UiActivationKeys = group.SelectMany(item => item.capability.UiActivationKeys).Distinct(StringComparer.OrdinalIgnoreCase).ToList(),
                IsOnline = group.Any(item => item.capability.IsOnline),
                IsEnabled = group.Any(item => item.capability.IsEnabled),
                UpdatedUtc = DateTimeOffset.UtcNow
            })
            .OrderBy(item => item.Key, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    /// <summary>
    /// Gets UI features async.
    /// </summary>
    public Task<IReadOnlyList<OrganicUiFeatureDescriptor>> GetUiFeaturesAsync(CancellationToken cancellationToken = default) =>
        Task.FromResult<IReadOnlyList<OrganicUiFeatureDescriptor>>
        ([
            new() { Key = "publisherstudio.council.run", DisplayName = "AI Council ribbon", State = OrganicUiFeatureState.Enabled, RequiredCapabilityKeys = ["council.run"] },
            new() { Key = "publisherstudio.council.team-picker", DisplayName = "Council team picker", State = OrganicUiFeatureState.Enabled, RequiredCapabilityKeys = ["council.teams"] },
            new() { Key = "publisherstudio.screenreader.recurring", DisplayName = "Recurring screen-reader help", State = OrganicUiFeatureState.Enabled, RequiredCapabilityKeys = ["publisher.screen.capture"] },
            new() { Key = "publisherstudio.spreadsheet.ai", DisplayName = "Spreadsheet AI help", State = OrganicUiFeatureState.Enabled, RequiredCapabilityKeys = ["publisher.spreadsheet.inspect", "council.run"] },
            new() { Key = "publisherstudio.openscad.ai", DisplayName = "OpenSCAD Team", State = OrganicUiFeatureState.Enabled, RequiredCapabilityKeys = ["publisher.openscad.generate", "council.run"] },
            new() { Key = "publisherstudio.picture.ocr", DisplayName = "Picture Studio OCR", State = OrganicUiFeatureState.Enabled, RequiredCapabilityKeys = ["localgpt.vision.ocr"] },
            new() { Key = "publisherstudio.security", DisplayName = "Secure 1-Wire link", State = OrganicUiFeatureState.Enabled, RequiredCapabilityKeys = [] }
        ]);

    /// <summary>
    /// Gets hardware async.
    /// </summary>
    public Task<IReadOnlyList<OrganicHardwareDescriptor>> GetHardwareAsync(CancellationToken cancellationToken = default) =>
        Task.FromResult<IReadOnlyList<OrganicHardwareDescriptor>>
        ([
            new()
            {
                Kind = OrganicHardwareKind.Cpu, Index = 0, Name = Environment.GetEnvironmentVariable("PROCESSOR_IDENTIFIER") ?? "CPU",
                Vendor = Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE") ?? string.Empty,
                LogicalProcessorCount = Environment.ProcessorCount, IsOnline = true
            }
        ]);

    private OrganicCapabilityDescriptor Capability(string key, string name, string description, string organ, bool readOnly, bool confirmation, bool scheduling) => new()
    {
        Key = key, DisplayName = name, Description = description, Controller = "OrganicPlugins", Method = "POST",
        Route = $"/api/organic/capabilities/{key}", Organs = [organ], Skills = Skills(key), RequiredSkillKeys = Skills(key),
        UiActivationKeys = UiActivationKeys(key), IsOnline = true, IsEnabled = true,
        IsReadOnly = readOnly, RequiresHumanConfirmation = confirmation, SupportsScheduling = scheduling,
        SupportsRecurringExecution = key is "publisher.screenreader.start",
        RequiresHumanInteractionOnTargetSystem = confirmation,
        RequiresAutomatedInteractionOnTargetSystem = key is "publisher.screen.capture" or "publisher.screen.record" or "publisher.input.execute" or "publisher.screenreader.start" or "publisher.screenreader.stop",
        IsExposedToPeer = true,
        AllowPeerInvocation = true,
        RequiresFrontendUserConfirmation = confirmation,
        InteractionEditor = key is "publisher.text.insert.propose" or "publisher.text.edit.request" or "publisher.website.content.request"
            ? OrganicInteractionEditor.RichText
            : confirmation
                ? OrganicInteractionEditor.ConfirmationOnly
                : OrganicInteractionEditor.None,
        ConfigurationKey = $"publisher:{key}",
        ParameterSchemaJson = Schema(key),
        InputContract = InputContract(key),
        OutputContract = OutputContract(key),
        SecurityContract = SecurityContract(key),
        OrganicUseCase = OrganicUseCase(key),
        SuggestedCouncilRoles = SuggestedCouncilRoles(key),
        Source = "PublisherStudio"
    };

    private List<string> UiActivationKeys(string key) => key switch
    {
        "publisher.screen.capture" => ["publisherstudio.screenreader.recurring"],
        "publisher.screenreader.start" => ["publisherstudio.screenreader.recurring"],
        "publisher.screenreader.stop" => ["publisherstudio.screenreader.recurring"],
        "publisher.openscad.generate" => ["publisherstudio.openscad.ai"],
        "publisher.spreadsheet.inspect" => ["publisherstudio.spreadsheet.ai"],
        _ => []
    };

    private List<string> Skills(string key) => key switch
    {
        "publisher.screen.capture" => ["vision", "screen", "screenshot"],
        "publisher.screen.capture.result" => ["vision", "screen", "screenshot", "evidence"],
        "publisher.screen.record" => ["vision", "screen", "video", "evidence"],
        "publisher.screenreader.start" => ["vision", "screen", "screenreader", "recurring"],
        "publisher.screenreader.stop" => ["vision", "screen", "screenreader", "recurring"],
        "publisher.input.execute" => ["mouse", "keyboard", "gesture", "navigation"],
        "publisher.input.result" => ["mouse", "keyboard", "gesture", "verification"],
        "publisher.openscad.generate" => ["openscad", "3d", "geometry", "render"],
        "publisher.spreadsheet.inspect" => ["spreadsheet", "workbook", "analysis"],
        "publisher.text.insert.propose" => ["text", "editing", "proposal"],
        "publisher.text.edit.request" => ["text", "editing", "human-feedback"],
        "publisher.website.content.request" => ["html", "document", "website", "approved-content"],
        "publisher.media.capabilities" => ["ffmpeg", "video", "audio", "conversion"],
        _ => ["publisherstudio", "project-context"]
    };

    private string Schema(string key) => key switch
    {
        "publisher.screen.capture" => "{\"type\":\"object\",\"properties\":{\"selector\":{\"type\":\"string\"},\"format\":{\"type\":\"string\"},\"quality\":{\"type\":\"number\"}}}",
        "publisher.screen.capture.result" => "{\"type\":\"object\",\"required\":[\"requestId\"],\"properties\":{\"requestId\":{\"type\":\"string\"},\"includeData\":{\"type\":\"boolean\"}}}",
        "publisher.screen.record" => "{\"type\":\"object\",\"properties\":{\"maximumSeconds\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":15},\"includeAudio\":{\"type\":\"boolean\"}}}",
        "publisher.screenreader.start" => "{\"type\":\"object\",\"properties\":{\"selector\":{\"type\":\"string\"},\"prompt\":{\"type\":\"string\"},\"intervalSeconds\":{\"type\":\"integer\",\"minimum\":15}}}",
        "publisher.screenreader.stop" => "{\"type\":\"object\",\"required\":[\"sessionId\"],\"properties\":{\"sessionId\":{\"type\":\"string\"}}}",
        "publisher.input.execute" => "{\"type\":\"object\",\"required\":[\"kind\"],\"properties\":{\"kind\":{\"type\":\"string\"},\"selector\":{\"type\":\"string\"},\"text\":{\"type\":\"string\"},\"key\":{\"type\":\"string\"},\"x\":{\"type\":\"number\"},\"y\":{\"type\":\"number\"}}}",
        "publisher.input.result" => "{\"type\":\"object\",\"required\":[\"requestId\"],\"properties\":{\"requestId\":{\"type\":\"string\"}}}",
        "publisher.openscad.generate" => "{\"type\":\"object\",\"required\":[\"document\"],\"properties\":{\"document\":{\"type\":\"object\"}}}",
        "publisher.spreadsheet.inspect" => "{\"type\":\"object\",\"required\":[\"sessionId\"],\"properties\":{\"sessionId\":{\"type\":\"string\"}}}",
        "publisher.text.insert.propose" => "{\"type\":\"object\",\"required\":[\"text\"],\"properties\":{\"target\":{\"type\":\"string\"},\"text\":{\"type\":\"string\"},\"reason\":{\"type\":\"string\"}}}",
        "publisher.text.edit.request" => "{\"type\":\"object\",\"properties\":{\"title\":{\"type\":\"string\"},\"question\":{\"type\":\"string\"},\"initialText\":{\"type\":\"string\"}}}",
        "publisher.website.content.request" => "{\"type\":\"object\",\"properties\":{\"format\":{\"enum\":[\"html\",\"div\",\"document\"]},\"sourceUrl\":{\"type\":\"string\"},\"maximumCharacters\":{\"type\":\"integer\",\"maximum\":200000}}}",
        _ => "{\"type\":\"object\",\"properties\":{}}"
    };

    private string InputContract(string key) => key switch
    {
        "publisher.screen.capture" => "No image path. The PublisherStudio user selects a screen/window in a fresh browser prompt.",
        "publisher.screen.record" => "maximumSeconds 1..15 and optional audio flag; the user selects the capture source in the browser.",
        "publisher.text.edit.request" => "A title, question and optional initial text. The human edits the value in PublisherStudio.",
        "publisher.website.content.request" => "Requested html/div/document format, optional source URL and maximum character count.",
        _ => $"Parameters matching: {Schema(key)}"
    };

    private string OutputContract(string key) => key switch
    {
        "publisher.screen.capture" => "A bounded PNG data URL and pixel metadata returned in the current WorkResult.",
        "publisher.screen.record" => "A bounded WebM data URL, duration and MIME type returned in the current WorkResult.",
        "publisher.text.edit.request" => "The exact user-saved text, ContentType and CorrelationId; the editor closes after Save & return.",
        "publisher.website.content.request" => "Approved bounded content, format, optional source URL and truncation metadata.",
        _ => "A bounded JSON WorkResult associated with the original CorrelationId."
    };

    private string SecurityContract(string key) => key switch
    {
        "publisher.screen.capture" or "publisher.screen.record" => "Always asks in LocalGPT, always asks in PublisherStudio, and always invokes the browser's current getDisplayMedia permission prompt. Saved permission cannot bypass it.",
        "publisher.text.edit.request" or "publisher.website.content.request" => "Requires the receiving PublisherStudio frontend for every current request. Content is encrypted after MFA trust is established.",
        _ => "Requires an explicitly linked peer and the PublisherStudio exposure/invocation permission matrix."
    };

    private string OrganicUseCase(string key) => key switch
    {
        "publisher.screen.capture" or "publisher.screen.record" => "Eyes organ for current visual evidence.",
        "publisher.text.edit.request" => "Human feedback organ for Council questions and reviewed text.",
        "publisher.website.content.request" => "Approved document/web-content organ usable by LocalGPT and other 1-Wire clients.",
        _ => "PublisherStudio organic capability."
    };

    private List<string> SuggestedCouncilRoles(string key) => key switch
    {
        "publisher.screen.capture" or "publisher.screen.record" => ["vision member", "evidence verifier"],
        "publisher.text.edit.request" => ["council leader", "human collaboration coordinator"],
        "publisher.website.content.request" => ["web/document specialist", "content reviewer"],
        _ => Skills(key)
    };
}

/// <summary>
/// Represents an organic work executor.
/// </summary>
public sealed class OrganicWorkExecutor(
    IOrganicPluginProtocolCodec codec,
    IUserInputAutomationService input,
    IScreenshotCaptureService screenshots,
    IOpenScadDocumentService openScad,
    SpreadsheetSessionStore spreadsheetSessions,
    IBusinessObjectContextService businessContext,
    IMediaConversionService mediaConversion,
    IOrganicResultStore resultStore,
    IRecurringScreenReaderService recurringScreenReader,
    ILogger<OrganicWorkExecutor> logger) : IOrganicWorkExecutor
{
    /// <summary>
    /// Runs the execute async operation.
    /// </summary>
    public async Task<string> ExecuteAsync(OrganicWireEnvelope envelope, CancellationToken cancellationToken = default)
    {
        var parameters = ReadParameters(envelope);
        object result;
        if (string.Equals(envelope.CapabilityKey, "publisher.screenreader.start", StringComparison.OrdinalIgnoreCase))
        {
            var session = await recurringScreenReader.StartAsync(
                envelope.SourcePeerId,
                GetString(parameters, "selector", "body"),
                GetString(parameters, "prompt", "Describe meaningful screen changes and suggest the next safe action."),
                GetInt(parameters, "intervalSeconds", 15),
                cancellationToken).ConfigureAwait(false);
            result = new { session.Id, session.IsActive, session.Selector, session.Prompt, session.IntervalSeconds, MinimumIntervalSeconds = 15 };
        }
        else if (string.Equals(envelope.CapabilityKey, "publisher.screenreader.stop", StringComparison.OrdinalIgnoreCase))
        {
            if (!Guid.TryParse(GetString(parameters, "sessionId", string.Empty), out var sessionId))
                throw new ArgumentException("sessionId is required.");
            result = new { SessionId = sessionId, Stopped = await recurringScreenReader.StopAsync(sessionId).ConfigureAwait(false) };
        }
        else
        {
            result = envelope.CapabilityKey switch
            {
                "publisher.screen.capture" => ReadSecureCapture(envelope, "image"),
                "publisher.screen.record" => ReadSecureCapture(envelope, "video"),
                "publisher.screen.capture.result" => ReadScreenshotResult(parameters),
                "publisher.input.execute" => QueueInput(parameters),
                "publisher.input.result" => ReadInputResult(parameters),
                "publisher.openscad.generate" => GenerateOpenScad(parameters),
                "publisher.spreadsheet.inspect" => InspectSpreadsheet(parameters),
                "publisher.text.insert.propose" => ProposeText(parameters),
                "publisher.text.edit.request" => ReturnReviewedText(envelope, parameters),
                "publisher.website.content.request" => ReturnApprovedWebContent(envelope, parameters),
                "publisher.business-context" => businessContext.CreateSnapshot(),
                "publisher.media.capabilities" => await mediaConversion.GetCapabilitiesAsync(cancellationToken).ConfigureAwait(false),
                _ => throw new KeyNotFoundException($"Unknown organic capability '{envelope.CapabilityKey}'.")
            };
        }
        logger.LogInformation("Executed organic capability {CapabilityKey} for correlation {CorrelationId}.", envelope.CapabilityKey, envelope.CorrelationId);
        return JsonSerializer.Serialize(result, codec.JsonOptions);
    }

    private object QueueScreenshot(JsonElement parameters)
    {
        var request = new BrowserScreenshotRequest
        {
            Selector = GetString(parameters, "selector", "body"),
            Format = GetString(parameters, "format", "png"),
            Quality = GetDouble(parameters, "quality", .92),
            Scale = GetDouble(parameters, "scale", 1),
            IncludeMetadata = GetBoolean(parameters, "includeMetadata", true)
        };
        var queued = screenshots.Enqueue(request);
        return new
        {
            queued.Id,
            queued.Status,
            RequiresPublisherFrontendConfirmation = true,
            RequiresBrowserUserGesture = true,
            RequiresCurrentBrowserSessionPermission = true,
            BrowserPermissionCannotBePreGrantedByLocalGpt = true,
            NextCapability = "publisher.screen.capture.result followed by council continuation"
        };
    }

    private object ReadSecureCapture(OrganicWireEnvelope envelope, string expectedKind)
    {
        if (string.IsNullOrWhiteSpace(envelope.InteractionValueJson))
            throw new InvalidOperationException("The PublisherStudio browser did not return current capture data after approval.");
        using var document = JsonDocument.Parse(envelope.InteractionValueJson);
        var root = document.RootElement;
        var kind = GetString(root, "kind", string.Empty);
        var dataUrl = GetString(root, "dataUrl", string.Empty);
        var mimeType = GetString(root, "mimeType", string.Empty);
        if (!string.Equals(kind, expectedKind, StringComparison.OrdinalIgnoreCase) || string.IsNullOrWhiteSpace(dataUrl))
            throw new InvalidDataException($"The browser returned no approved {expectedKind} capture.");
        if (System.Text.Encoding.UTF8.GetByteCount(dataUrl) > OrganicWireProtocol.MaximumMessageBytes - 65536)
            throw new InvalidOperationException("The browser capture exceeds the bounded 1-Wire message size.");
        return new
        {
            Kind = kind, DataUrl = dataUrl, MimeType = mimeType,
            PixelWidth = GetInt(root, "width", 0), PixelHeight = GetInt(root, "height", 0),
            DurationMilliseconds = GetInt(root, "durationMilliseconds", 0),
            CapturedUtc = DateTimeOffset.UtcNow,
            RequiresHumanReview = true
        };
    }

    private object ReturnReviewedText(OrganicWireEnvelope envelope, JsonElement parameters)
    {
        var text = envelope.InteractionValueJson ?? string.Empty;
        if (string.IsNullOrWhiteSpace(text))
            throw new InvalidOperationException("The PublisherStudio user saved no text for the current request.");
        if (text.Length > 200000) text = text[..200000];
        return new
        {
            Text = text,
            Title = GetString(parameters, "title", "LocalGPT text request"),
            ContentType = envelope.InteractionValueContentType,
            envelope.CorrelationId,
            SavedByPublisherStudioUser = true,
            EditorClosedAfterSave = true
        };
    }

    private object ReturnApprovedWebContent(OrganicWireEnvelope envelope, JsonElement parameters)
    {
        var content = envelope.InteractionValueJson ?? string.Empty;
        var maximum = Math.Clamp(GetInt(parameters, "maximumCharacters", 120000), 1000, 200000);
        var truncated = content.Length > maximum;
        if (truncated) content = content[..maximum];
        return new
        {
            Format = GetString(parameters, "format", "html"),
            SourceUrl = GetString(parameters, "sourceUrl", string.Empty),
            Content = content,
            Truncated = truncated,
            MaximumCharacters = maximum,
            ApprovedByPublisherStudioUser = true,
            envelope.CorrelationId
        };
    }

    private object QueueInput(JsonElement parameters)
    {
        var kindName = GetString(parameters, "kind", string.Empty);
        if (!Enum.TryParse<BrowserAutomationCommandKind>(kindName, true, out var kind))
            throw new ArgumentException("A valid browser automation kind is required.");
        var command = new BrowserAutomationCommand
        {
            Kind = kind, Selector = GetString(parameters, "selector", string.Empty), Text = GetString(parameters, "text", string.Empty),
            Key = GetString(parameters, "key", string.Empty), Code = GetString(parameters, "code", string.Empty),
            Button = GetInt(parameters, "button", 0), X = GetDouble(parameters, "x", 0), Y = GetDouble(parameters, "y", 0),
            DeltaX = GetDouble(parameters, "deltaX", 0), DeltaY = GetDouble(parameters, "deltaY", 0),
            CtrlKey = GetBoolean(parameters, "ctrlKey", false), ShiftKey = GetBoolean(parameters, "shiftKey", false),
            AltKey = GetBoolean(parameters, "altKey", false), MetaKey = GetBoolean(parameters, "metaKey", false)
        };
        var queued = input.Enqueue(command);
        return new { queued.Id, queued.Status, GestureOwner = "PublisherStudio browser automation queue" };
    }

    private object ReadScreenshotResult(JsonElement parameters)
    {
        if (!Guid.TryParse(GetString(parameters, "requestId", string.Empty), out var requestId))
            throw new ArgumentException("requestId is required.");
        if (!screenshots.TryGet(requestId, out var request))
            throw new KeyNotFoundException("Screenshot request not found or expired.");
        var includeData = GetBoolean(parameters, "includeData", true);
        var dataUrl = includeData ? request.DataUrl : string.Empty;
        if (System.Text.Encoding.UTF8.GetByteCount(dataUrl) > OrganicWireProtocol.MaximumMessageBytes)
            throw new InvalidOperationException("The screenshot result exceeds the configured 1-Wire message capacity. Increase OrganicPlugins:MaximumMessageBytes or request metadata only.");
        return new
        {
            request.Id, request.Status, request.PixelWidth, request.PixelHeight, request.Error,
            DataUrl = dataUrl,
            DataIncluded = includeData && !string.IsNullOrWhiteSpace(dataUrl),
            ReadyForNextHeartbeat = request.Status is AutomationRequestStatus.Completed or AutomationRequestStatus.Failed or AutomationRequestStatus.Cancelled
        };
    }

    private object ReadInputResult(JsonElement parameters)
    {
        if (!Guid.TryParse(GetString(parameters, "requestId", string.Empty), out var requestId))
            throw new ArgumentException("requestId is required.");
        var command = input.GetAll().FirstOrDefault(candidate => candidate.Id == requestId)
            ?? throw new KeyNotFoundException("Browser input request not found or expired.");
        return new
        {
            command.Id, command.Kind, command.Selector, command.Status, command.Result, command.Error,
            ReadyForNextHeartbeat = command.Status is AutomationRequestStatus.Completed or AutomationRequestStatus.Failed or AutomationRequestStatus.Cancelled
        };
    }

    private object GenerateOpenScad(JsonElement parameters)
    {
        if (!parameters.TryGetProperty("document", out var documentElement)) throw new ArgumentException("document is required.");
        var document = documentElement.Deserialize<OpenScadDocument>(codec.JsonOptions) ?? throw new ArgumentException("document is invalid.");
        return openScad.Generate(document);
    }

    private object InspectSpreadsheet(JsonElement parameters)
    {
        if (!Guid.TryParse(GetString(parameters, "sessionId", string.Empty), out var sessionId)) throw new ArgumentException("sessionId is required.");
        if (!spreadsheetSessions.TryGet(sessionId, out var session)) throw new KeyNotFoundException("Spreadsheet session not found or expired.");
        return new
        {
            session.Id, session.ElementId, session.DocumentId, session.FileName, session.SourceFormat, session.ActiveSheetName,
            ContentBytes = session.Content.Length,
            ContentSha256 = Convert.ToHexString(SHA256.HashData(session.Content)),
            PreviewHtml = session.PreviewHtml.Length <= 24000 ? session.PreviewHtml : session.PreviewHtml[..24000] + "…",
            ReadOnlyInspection = true
        };
    }

    private object ProposeText(JsonElement parameters)
    {
        var proposal = new OrganicTextInsertionProposal
        {
            Target = GetString(parameters, "target", "current selection"),
            Text = GetString(parameters, "text", string.Empty),
            Reason = GetString(parameters, "reason", "AI Council proposal")
        };
        if (string.IsNullOrWhiteSpace(proposal.Text)) throw new ArgumentException("text is required.");
        resultStore.AddTextProposal(proposal);
        return new { proposal.Id, proposal.Target, proposal.Text, proposal.Reason, RequiresUserAcceptance = true };
    }

    private JsonElement ReadParameters(OrganicWireEnvelope envelope)
    {
        if (envelope.Properties is not null && envelope.Properties.TryGetValue("Parameters", out var parameters)) return parameters;
        return JsonSerializer.SerializeToElement(new { }, codec.JsonOptions);
    }
    private string GetString(JsonElement root, string name, string fallback) => root.ValueKind == JsonValueKind.Object && root.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.String ? value.GetString() ?? fallback : fallback;
    private double GetDouble(JsonElement root, string name, double fallback) => root.ValueKind == JsonValueKind.Object && root.TryGetProperty(name, out var value) && value.TryGetDouble(out var result) ? result : fallback;
    private int GetInt(JsonElement root, string name, int fallback) => root.ValueKind == JsonValueKind.Object && root.TryGetProperty(name, out var value) && value.TryGetInt32(out var result) ? result : fallback;
    private bool GetBoolean(JsonElement root, string name, bool fallback) => root.ValueKind == JsonValueKind.Object && root.TryGetProperty(name, out var value) && value.ValueKind is JsonValueKind.True or JsonValueKind.False ? value.GetBoolean() : fallback;
}

/// <summary>
/// Represents an organic work coordinator.
/// </summary>
public sealed class OrganicWorkCoordinator(
    IOrganicPluginProtocolCodec codec,
    IOrganicPermissionStore permissions,
    IOrganicCapabilityCatalog capabilityCatalog,
    IOrganicWorkExecutor executor,
    ILogger<OrganicWorkCoordinator> logger) : IOrganicWorkCoordinator
{
    private readonly ConcurrentDictionary<Guid, OrganicPluginWorkItem> work = new();
    private readonly ConcurrentDictionary<string, SemaphoreSlim> workflowGates = new(StringComparer.Ordinal);
    /// <summary>
    /// Occurs when changed.
    /// </summary>
    public event Action? Changed;

    /// <summary>
    /// Gets work.
    /// </summary>
    public IReadOnlyList<OrganicPluginWorkItem> GetWork() => work.Values.OrderByDescending(item => item.CreatedUtc).Take(250).ToList();
    /// <summary>
    /// Runs the get operation.
    /// </summary>
    public OrganicPluginWorkItem? Get(Guid id) => work.GetValueOrDefault(id);

    /// <summary>
    /// Runs the receive async operation.
    /// </summary>
    public async Task<OrganicPluginWorkItem> ReceiveAsync(OrganicWireEnvelope envelope, CancellationToken cancellationToken = default)
    {
        var advertised = (await capabilityCatalog.GetCapabilitiesAsync(cancellationToken).ConfigureAwait(false))
            .FirstOrDefault(capability => string.Equals(capability.Key, envelope.CapabilityKey, StringComparison.OrdinalIgnoreCase));
        var permission = permissions.Resolve(envelope.SourcePeerId, envelope.CapabilityKey, envelope.Organs.FirstOrDefault() ?? string.Empty)
            ?? permissions.Resolve(envelope.SourcePeerId, envelope.CapabilityKey);
        var exposed = advertised is not null && advertised.IsEnabled && advertised.IsOnline &&
            advertised.AllowPeerInvocation && permissions.IsCapabilityExposed(envelope.SourcePeerId, advertised) &&
            (permission?.AllowInvocation ?? true);
        if (advertised is not null)
        {
            envelope.RequiresHumanInteractionOnTargetSystem = permission?.RequiresFrontendConfirmation
                ?? advertised.RequiresFrontendUserConfirmation
                || advertised.RequiresHumanConfirmation;
            envelope.Properties ??= new Dictionary<string, JsonElement>(StringComparer.Ordinal);
            envelope.Properties["InteractionEditor"] = JsonSerializer.SerializeToElement(
                (permission?.InteractionEditor ?? advertised.InteractionEditor).ToString(), codec.JsonOptions);
            envelope.Properties["ConfigurationKey"] = JsonSerializer.SerializeToElement(
                advertised.ConfigurationKey, codec.JsonOptions);
        }
        var requiresFreshCaptureConsent = envelope.CapabilityKey is "publisher.screen.capture" or "publisher.screen.record";
        if (requiresFreshCaptureConsent)
        {
            // Screen sharing is deliberately non-persistable. Even an AllowAlways rule may not bypass
            // the current PublisherStudio confirmation and the browser's fresh getDisplayMedia prompt.
            envelope.RequiresHumanInteractionOnTargetSystem = true;
            envelope.ApprovalMode = OrganicApprovalMode.AskEveryTime;
            envelope.NormalizeInteractionKind();
        }
        var item = new OrganicPluginWorkItem
        {
            MessageId = envelope.MessageId, CorrelationId = envelope.CorrelationId, PeerId = envelope.SourcePeerId,
            CapabilityKey = envelope.CapabilityKey, Request = envelope,
            Status = !exposed || permissions.IsDenied(envelope)
                ? OrganicWorkStatus.Declined
                : requiresFreshCaptureConsent
                    ? OrganicWorkStatus.PendingApproval
                    : permissions.IsAllowed(envelope)
                        ? OrganicWorkStatus.Queued
                        : OrganicWorkStatus.PendingApproval
        };
        if (item.Status == OrganicWorkStatus.Declined)
            item.Error = advertised is null
                ? "The requested capability is not registered in PublisherStudio."
                : !exposed
                    ? "The PublisherStudio frontend catalog does not expose this capability to the connected peer."
                    : "Denied by the PublisherStudio organic permission policy.";
        work[item.Id] = item;
        Changed?.Invoke();
        if (item.Status == OrganicWorkStatus.Queued)
            await ExecuteAsync(item, cancellationToken).ConfigureAwait(false);
        else if (item.Status == OrganicWorkStatus.PendingApproval)
            logger.LogInformation("Organic work {WorkItemId} awaits PublisherStudio user approval for {CapabilityKey}.", item.Id, item.CapabilityKey);
        else
            logger.LogWarning("Organic work {WorkItemId} was denied by the PublisherStudio permission policy for {CapabilityKey}.", item.Id, item.CapabilityKey);
        return item;
    }

    /// <summary>
    /// Runs the approve async operation.
    /// </summary>
    public async Task<OrganicPluginWorkItem?> ApproveAsync(Guid id, CancellationToken cancellationToken = default)
    {
        if (!work.TryGetValue(id, out var item) || item.Status != OrganicWorkStatus.PendingApproval) return item;
        item.Request.UserConfirmed = true;
        item.Status = OrganicWorkStatus.Queued;
        item.UpdatedUtc = DateTimeOffset.UtcNow;
        Changed?.Invoke();
        await ExecuteAsync(item, cancellationToken).ConfigureAwait(false);
        return item;
    }

    /// <summary>
    /// Updates interaction value.
    /// </summary>
    public bool UpdateInteractionValue(Guid id, string value)
    {
        if (!work.TryGetValue(id, out var item) || item.Status != OrganicWorkStatus.PendingApproval)
            return false;
        item.Request.InteractionValueJson = value ?? string.Empty;
        var editor = ReadInteractionEditor(item.Request);
        item.Request.InteractionValueContentType = editor == OrganicInteractionEditor.Json
            ? "application/json"
            : "text/plain; charset=utf-8";
        item.UpdatedUtc = DateTimeOffset.UtcNow;
        Changed?.Invoke();
        return true;
    }

    private OrganicInteractionEditor ReadInteractionEditor(OrganicWireEnvelope envelope)
    {
        if (envelope.Properties is not null && envelope.Properties.TryGetValue("InteractionEditor", out var value))
        {
            if (value.ValueKind == JsonValueKind.String && Enum.TryParse<OrganicInteractionEditor>(value.GetString(), true, out var parsed))
                return parsed;
            if (value.ValueKind == JsonValueKind.Number && value.TryGetInt32(out var numeric) && Enum.IsDefined(typeof(OrganicInteractionEditor), numeric))
                return (OrganicInteractionEditor)numeric;
        }
        return envelope.RequiresHumanInteractionOnTargetSystem ? OrganicInteractionEditor.ConfirmationOnly : OrganicInteractionEditor.None;
    }

    /// <summary>
    /// Runs the decline operation.
    /// </summary>
    public bool Decline(Guid id, string reason)
    {
        if (!work.TryGetValue(id, out var item) || item.Status != OrganicWorkStatus.PendingApproval) return false;
        item.Status = OrganicWorkStatus.Declined;
        item.Error = string.IsNullOrWhiteSpace(reason) ? "Declined by PublisherStudio user." : reason;
        item.UpdatedUtc = DateTimeOffset.UtcNow;
        Changed?.Invoke();
        return true;
    }

    private async Task ExecuteAsync(OrganicPluginWorkItem item, CancellationToken cancellationToken)
    {
        var key = string.IsNullOrWhiteSpace(item.Request.WorkOrderKey) ? item.Id.ToString("N") : item.Request.WorkOrderKey;
        var workflowGate = workflowGates.GetOrAdd(key, _ => new SemaphoreSlim(1, 1));
        await workflowGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            if (item.Request.ExecutionMode == OrganicExecutionMode.Scheduled && item.Request.NotBeforeUtc is { } notBefore && notBefore > DateTimeOffset.UtcNow)
            {
                item.Status = OrganicWorkStatus.Queued;
                item.UpdatedUtc = DateTimeOffset.UtcNow;
                Changed?.Invoke();
                var delay = notBefore - DateTimeOffset.UtcNow;
                if (delay > TimeSpan.Zero)
                    await Task.Delay(delay, cancellationToken).ConfigureAwait(false);
            }
            item.Status = OrganicWorkStatus.Running;
            item.UpdatedUtc = DateTimeOffset.UtcNow;
            Changed?.Invoke();
            item.ResultJson = await executor.ExecuteAsync(item.Request, cancellationToken).ConfigureAwait(false);
            item.Status = OrganicWorkStatus.Completed;
            item.Error = string.Empty;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            item.Status = OrganicWorkStatus.Cancelled;
            item.Error = "Cancelled.";
        }
        catch (Exception ex)
        {
            item.Status = OrganicWorkStatus.Failed;
            item.Error = ex.Message;
            logger.LogError(ex, "Organic work {WorkItemId} failed for {CapabilityKey}.", item.Id, item.CapabilityKey);
        }
        finally
        {
            item.UpdatedUtc = DateTimeOffset.UtcNow;
            workflowGate.Release();
            Changed?.Invoke();
        }
    }
}
